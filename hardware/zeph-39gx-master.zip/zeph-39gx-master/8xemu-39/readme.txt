Status:

Run to 'Memory Clear'.

  Working:
  CPU/Chipset
  Display

  Not working:
  Link
  Keypad

Outputs:

For KEIL MDK-ARM: .\obj
For IAR EWARM: .\proj\Debug 