#ifndef __SYSBASE_H__
#define __SYSBASE_H__
extern "C" {
#include "misc.h"
#include "2410addr.h"
#include "buzz.h"
#include "misc.h"
#include "hwlcd.h"
#include "key.h"
}
#endif
