/***************************************************
             HP 39GS Repurpose Project
			              by Zweb
		      nbzwt@live.cn  www.zephray.com
***************************************************/

#ifndef __INTERFACE_H__
#define __INTERFACE_H__

#include "misc.h"

#endif
