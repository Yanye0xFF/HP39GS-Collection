/***************************************************
             HP 39GS Repurpose Project
			              by Zweb
		      nbzwt@live.cn  www.arithmax.org
***************************************************/

#ifndef __MISC_H__
#define __MISC_H__

#define u32 unsigned int
#define u16 unsigned short
#define u8  unsigned char

#define s32 signed int
#define s16 signed short
#define s8  signed char

void Delay(unsigned long t);
void Delayus(unsigned int t);

#endif
