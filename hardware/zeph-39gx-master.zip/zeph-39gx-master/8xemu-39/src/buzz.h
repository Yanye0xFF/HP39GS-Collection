/***************************************************
             HP 39GS Repurpose Project
			              by Zweb
		      nbzwt@live.cn  www.arithmax.org
***************************************************/

#ifndef __BUZZ_H__
#define __BUZZ_H__

void Buzzer_Start(unsigned long freq);
void Buzzer_Stop(void);

#endif
