			*****************************************
			*	     	    ADK			*
			*              for HP39/40G		*
			*            Version 1.39.02		*
			*	   Based on the 38G ADK		*
			*	         by Noda		*
			*          E-mail: noda@goa.as		*
			*****************************************

Thanks to Colin Croft, I have been able to have the sources of the HP38G ADK, so I
have modified it and improved it to make now a near perfect HP39/40G ADK!


Features:
--------
-HP39/40G compatibility
-Fixed the Custom View Bug
-Changed the Next View List according to the HP39/40G map
-Added support for the Inference aplet
-Added support for the Quad Explorer aplet
-Added support for the Trig Explorer aplet
-Changed the sketch limitation from 10 to 30 (the HP39/40G limit)
