Minesweep Greyscale

HP49 port and code optimizations by Pagala
HP39/40 port by HP-Poska

Original Author Unknown

This zip contains 2 code objects

  minesweep.48   Size = 1271.5  HPCRC = #73F1h  <-- Minesweep Variable for the 48
  minesweep.49   Size = 1283    HPCRC = #9FB0h  <-- Minesweep Variable for the 49

and one aplet

  HP39DIR.CUR
  HP39DIR.000
  MINESWEE.000  <-- Minesweep Aplet for the 39/40
  LIB1537L.000

- Just download the variable for the calculator you have and run it.
  It is that simple.

- Default mine value is 20 but if you want to play with more then put a real
  (or zint on 49) on the stack and run the variable. On the 39/40, you can get
  get access to this option in the Views list.

- This program is now 100% assembly and is mostly bug free
  (the original was quite buggy)

- Use the arrow keys to move around and Enter, +/- on the 48 and F1,F2 on the 49
  and 39/40 to push tiles down and mark mines.

- Although I tried removing all bugs it is still not 100% bug free so don't
  use this game if you have important data you don't want to lose in a TTRM.

- If this program doesn't work for some reason for you or screws
  up your calc in any way don't bitch at me I am doing the best I can.
  You can however write an E-mail and tell me whats wrong if you are having
  problems with it.

  My Email is pagaljae@hotmail.com

- For problems with the 39/40 version, contact HP-Poska at hposka@free.fr

  For more hp projects I have completed go to my web site at:
  http://members.xoom.com/pagala/hp
