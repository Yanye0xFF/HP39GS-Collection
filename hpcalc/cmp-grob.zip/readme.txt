==============================================================================
||                            --- README ---                                ||
||                 --- NIFTY GNARLY HP48 GROB VIEWER ---                    ||
||                     --- RADIOACTIVE SOFTWARE ---       v0.3              ||
==============================================================================

WHAT IS THIS README FILE FOR?

People who need help with the simplist of programs! (like this one)

THE PROGRAM--

   This program is designed to view hp GROBS. A grob is the file
  format that the calculator uses as graphics. The computer has GIF
  JPG,TIFF,PCX,BMP,IMG,PCD to name a few. The calculator has GROB.
  GROBs are commonly stored under .hp .

   How does the program display grobs? ( It's my little secret ) I
  will give you a few clues. GROBs use hexadecimal digits to store
  binary values.ex. F= 1111 , 0= 0000 1= 1000. The 1's and 0's represtent
  on and off respectively. My programs simply reads the Hexadecimal values
  and stores them as binary codes in to memory then changes each 1 to on and
  0 to off the moves it over to the Video Memory.

USING THE PROGRAM--

   GROB.exe will display the grobs. Currently it cannot read the width
  correctly so it assumes it is 135 by DEFAULT. Ok, Back to displaying
  GROBs.

  1) Load the program  ( grob.exe)

  2) The program will ask you what file you want to display.
     ex. you want to display 'dog.hp'
	type dog.hp or just type dog

  3) Then it will ask you if the size is standard (135) if so push no.

  4) If you pushed yes you must type the width of the image (you have to
       a number divisible by 4!

  5) That's all you should have a nice pretty picture!

WHAT IS INCLUDED IN THIS PACKAGE--

   GROB.exe       -- The main program
   README.txt     -- The file you are currently reading! Help for everyone!
   DOG.hp         -- a standard sized GROB of a strange dog
   PIG.hp         -- a standard sized GROB of a realistic pig
   DINO.hp        -- a standard sized GROB of a cool Trex

   all of the GROBs were supplied by ADAM CHAN.

FREQUENTLY ASKED QUESTIONS--

   WILL THIS PROGRAM BLOW UP MY COMPUTER?
     - I certainly hope not! It might blowup and Apple IIe

   HOW LONG DID THIS PROGRAM TAKE YOU TO BUILD?
     - Two days. I didn't spend all day doing it though.

   CAN I PUT THIS PROGRAM ON MY HP48?
     - NO!! THIS PROGRAM IS FOR COMPUTER ONLY!!!

   WILL GROB.exe RUN ON MY MAC?
     -NO and I am not planing for it to! I hate MACs!

CONTACT US!--

   You can reach us!
   
   PLEASE contact me with your questions,comments,requests,and FAQ's!
   so i can make this program better!

   Visit http://come.to/radio.active   for stuff!

   Contact me by EMAIL -
      paulgiblock@icx.net

   Contact me by ICQ   -
      my number is #12574637



			  ---------  NOTE  ---------
 radioactive software or Paul Giblock as an individual is NOT responsible for
 any damage to your machine. the package should NOT do any damage, but if for
   some reason it does, we're sorry and that's all I'm going to do. (I might
			send you a cookie of cupcake)
