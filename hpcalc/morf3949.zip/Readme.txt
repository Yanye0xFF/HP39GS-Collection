		*************************************************
		*						*
		*		       MorfD�mo			*
		*	    	  by Myrtillos & fde		*
		*						*
		*   HP49 & HP39/40 versions by Lilian Pigallio	*
		*		     Dec 2000  			*
		*               (pigallio@atsat.com)            *
		*************************************************



Very Important :
----------------

To download MorfD�mo on your HP39/40 don't use HPComm38 on your PC. Do like this :

	on your HP39/40, clic : Aplet/RECV/Wire AND NOT "Disk Drive"

	on your PC, use X-Modem software, for example Hyper-Terminal.
		Clic Send a file and then choose MorfDemo.000 and Xmodem
		Then clic send

