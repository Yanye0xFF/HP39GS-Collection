// JavaScript template using Windows Script Host
var WSHShell = WScript.CreateObject("WScript.Shell");
WSHShell.Popup( "Hello World!" );
