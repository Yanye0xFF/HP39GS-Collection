#ifndef __OLDNAMES_H
#define __OLDNAMES_H

// Aliases for backward compatibility

#define RTC_seconds sys_RTC_seconds
#define CancelHit keyb_isON

#endif // __OLDNAMES_H
