/*

This program showed up one day in a thread on comp.sys.hp48
It originates from http://www.users.waitrose.com/~nihilist/sudoku.html.

Here is the modified version for the HP49g+, which pops a string representation 
of a 9x9 matrix as its input from the RPL stack and pushes the solution (if any) back.

It's the responsibility of a small RPL front end, to do the appropriate conversions.

Given, that this program is properly compiled to a L3 string 'sudoku', the following will work:

<< ->STR sudoku PrRUN STR-> >>


NOTE:  In contrast to the original, this version DOES NOT require a SD card  and should 
therefore run on non g+ models too.

Ingo Blank
2005-08-03

*/


#include<hpgcc49.h>


#define SIZE 9
#define BLOCK_SIZE 3


/*****************************************************************************/
/* Assert macro.                                                             */
/*****************************************************************************/
#ifdef DEBUG
#define ASSERT(X) assert(X)
#else
#define ASSERT(X)
#endif

/*****************************************************************************/
/* Prototypes.                                                               */
/*****************************************************************************/
int initialize(const char *);
int attempt_to_solve(void);
int number_known(void);
int do_check(void);
void proc_block(int, int);
int unique_value(int, int);
char *dump();
void proc_row(int, int);
void proc_col(int, int);

/*****************************************************************************/
/* Global variables for tracking recursion depth.                            */
/*****************************************************************************/
 int max_rec_depth = 0;
 int cur_rec_depth = 0;

/*****************************************************************************/
/* Global solution array.                                                    */
/*                                                                           */
/* The second-to-top entry is used to keep track of the number of            */
/* candidates.  This is redundant information but is an optimization trading */
/* off storage for speed.                                                    */
/*                                                                           */
/* We also trade off storage for speed by storing the unique candidate, once */
/* it's found, in the top array entry.                                       */
/*****************************************************************************/
int sudoku[SIZE][SIZE][SIZE + 2];

/*****************************************************************************/
/* Handy macros.                                                             */
/*****************************************************************************/
#define FIXED_VAL(X,Y) sudoku[X][Y][SIZE+1]
#define CAND_COUNT(X,Y) sudoku[X][Y][SIZE]


int 
main()
{
    unsigned rpl_stack_bias = sat_stack_init();
    
    sys_slowOff();
  
    if (initialize((const char *) sat_stack_pop_string((char *) malloc(256)))) {
     
        if (attempt_to_solve())
            sat_stack_push_string(dump());
        else
            sat_stack_push_string("No solution");
        
    }else 
       
        sat_stack_push_string("Bad input");
  
 
    sat_stack_exit(rpl_stack_bias);
  
    return 0;
}


int initialize(const char *m)
{
  int i;
  int j;
  int k;
  int x;


  /***************************************************************************/
  /* Clear out the working array.  Wind through all the entries.             */
  /***************************************************************************/
  for (i=0;i<SIZE;i++)
  {
    for (j=0;j<SIZE;j++)
    {
      /***********************************************************************/
      /* Initialize next entry.  First make every number a candidate.        */
      /***********************************************************************/
      for (k=0;k<SIZE;k++)
      {
        sudoku[i][j][k] = TRUE;
      }

      /***********************************************************************/
      /* Initialize the candidate count.                                     */
      /***********************************************************************/
      CAND_COUNT(i,j) = SIZE;

        while (*m && (*m < '0' || *m > '9')) m++;
        x = *m - '0';
        if (x < 0 || x > SIZE)
            return FALSE;
        
        while(*m && *m >= '0' && *m <= '9') m++;
            
        
      if (x > 0)
      {
        /*********************************************************************/
        /* We have a known entry. Update our array thusly.                   */
        /*********************************************************************/
        for (k=0;k<SIZE;k++)
        {
          sudoku[i][j][k] = FALSE;
        }
        sudoku[i][j][x-1] = TRUE;

        /*********************************************************************/
        /* Set up the candidate count.                                       */
        /*********************************************************************/
        CAND_COUNT(i,j) = 1;

        /*********************************************************************/
        /* Set up the unique entry value.                                    */
        /*********************************************************************/
        FIXED_VAL(i,j) = x;
      }
    }
  }
  
  return TRUE;
}

 int attempt_to_solve(void)
{
  int num_known;
  int last_num_known = 0;
  int i = 0;
  int j = 0;
  int l;
  int mm;
  int success = TRUE;
  int saved_entry[SIZE+2];
  int saved_sudoku[SIZE][SIZE][SIZE+2];
  int done;

  /***************************************************************************/
  /* Increment recursion depth count.  We dump this info on completion for   */
  /* curiosity's sake.                                                       */
  /***************************************************************************/
  cur_rec_depth++;

  if (max_rec_depth < cur_rec_depth)
  {
    /*************************************************************************/
    /* We need to update the deepest-ever recursion statistic.               */
    /*************************************************************************/
    max_rec_depth = cur_rec_depth;
  }

  while (((num_known = number_known()) > last_num_known) &&
         (num_known < (SIZE*SIZE)))
  {
    /*************************************************************************/
    /* Iterate applying the logical conditions of Sudoku until we have no    */
    /* more effect on the number of known entries.                           */
    /*************************************************************************/
    last_num_known = num_known;

    /*************************************************************************/
    /* Wind through each entry looking for restrictions applied by each of   */
    /* its row, column and block.                                            */
    /*************************************************************************/
    for (i=0; i < SIZE; i++)
    {
      for (j=0; j < SIZE; j++)
      {
        if (CAND_COUNT(i,j) > 1)
        {
          /*******************************************************************/
          /* Check for constrictions applied by the row, column and block.   */
          /*******************************************************************/
          proc_row(i,j);
          proc_col(i,j);
          proc_block(i,j);
        }
      }
    }
  }

  /*************************************************************************/
  /* Check that we have a consistent array still.  If not, we have failed  */
  /* and an outer recursion will backtrack and guess a different value for */
  /* an entry.                                                             */
  /*************************************************************************/
  if (do_check() == FALSE)
  {
    success = FALSE;
    goto EXIT;
  }

  if (num_known == (SIZE * SIZE))
  {
    /*************************************************************************/
    /* We've solved the puzzle so return with success.                       */
    /*************************************************************************/
    goto EXIT;
  }

  /***************************************************************************/
  /* Not got a complete solution yet so we have to start guessing.  Look for */
  /* the first entry in the array that has more than one possible value.     */
  /***************************************************************************/
  done = FALSE;
  for (i=0;i<SIZE;i++)
  {
    for (j=0;j<SIZE;j++)
    {
      if (CAND_COUNT(i,j) > 1)
      {
        done = TRUE;
        break;
      }
    }

    if (done == TRUE)
    {
      break;
    }
  }

  /***************************************************************************/
  /* Save off a copy the entry candidate list that we're going to use.       */
  /* We're going to overwrite the data soon but we need to use it.           */
  /***************************************************************************/
  memcpy(saved_entry, sudoku[i][j], sizeof(sudoku[i][j]));

  /***************************************************************************/
  /* Wind through each candidate attempting to solve the puzzle by trying to */
  /* solve it using each of them in turn.                                    */
  /***************************************************************************/
  for (l=0;l<SIZE;l++)
  {
    if (saved_entry[l] == TRUE)
    {
      /***********************************************************************/
      /* Save the current partially-completed sudoku.                        */
      /***********************************************************************/
      memcpy(saved_sudoku, sudoku, sizeof(sudoku));

      /***********************************************************************/
      /* Found a candidate.  Set up the entry to make it look as though      */
      /* we've decided the value of this entry.                              */
      /***********************************************************************/
      for (mm=0;mm<SIZE;mm++)
      {
        sudoku[i][j][mm] = FALSE;
      }
      sudoku[i][j][l] = TRUE;

      /***********************************************************************/
      /* Set the candidate count to 1.                                       */
      /***********************************************************************/
      CAND_COUNT(i,j) = 1;

      /*********************************************************************/
      /* Set up the unique entry value.                                    */
      /*********************************************************************/
      FIXED_VAL(i,j) = l+1;

      /***********************************************************************/
      /* Recursively attempt to solve the grid now we've fixed an extra      */
      /* point as an educated guess.                                         */
      /***********************************************************************/
      success = attempt_to_solve();

      if (success == TRUE)
      {
        /*********************************************************************/
        /* We have a solution so quit.                                       */
        /*********************************************************************/
        goto EXIT;
      }
      else
      {
        /*********************************************************************/
        /* Restore the old partially-completed sudoku from before we failed. */
        /*********************************************************************/
        memcpy(sudoku, saved_sudoku, sizeof(sudoku));
      }
    }
  }

EXIT:

  /***************************************************************************/
  /* Decrement the current number of recursions.                             */
  /***************************************************************************/
  cur_rec_depth--;

  return (success);
}

 void proc_row(int i, int j)
{
  int k;

  /*********************************************************************/
  /* Check row containing this entry for restrictions we can apply to  */
  /* the current entry.                                                */
  /*********************************************************************/
  for (k=0; k < SIZE; k++)
  {
    if ((j != k) &&
        (CAND_COUNT(i,k) == 1) &&
        ((CAND_COUNT(i,j)) > 1))
    {
      if ((sudoku[i][j][FIXED_VAL(i,k) - 1]) == TRUE)
      {
        /*********************************************************************/
        /* Eliminate this candidate.                                         */
        /*********************************************************************/
        sudoku[i][j][FIXED_VAL(i,k) - 1] = FALSE;

        /*********************************************************************/
        /* Decrement the candidate count.                                    */
        /*********************************************************************/
        CAND_COUNT(i,j)--;

        if (CAND_COUNT(i,j) == 1)
        {
          /*******************************************************************/
          /* We have uniqueness.  Update the unique value slot.              */
          /*******************************************************************/
          FIXED_VAL(i,j) = unique_value(i,j);
        }
      }
    }
  }
  return;
}

 void proc_col(int i, int j)
{
  int k;

  /*********************************************************************/
  /* Check column containing this entry for restrictions we can apply  */
  /* to the current entry.                                             */
  /*********************************************************************/
  for (k=0; k < SIZE; k++)
  {
    if ((i != k) &&
        (CAND_COUNT(k,j) == 1) &&
        (CAND_COUNT(i,j) > 1))
    {
      if (sudoku[i][j][FIXED_VAL(k,j) - 1] == TRUE)
      {
        /*********************************************************************/
        /* Eliminate this value.                                             */
        /*********************************************************************/
        sudoku[i][j][FIXED_VAL(k,j) - 1] = FALSE;

        /*********************************************************************/
        /* Decrement the candidate count.                                    */
        /*********************************************************************/
        CAND_COUNT(i,j)--;

        if (CAND_COUNT(i,j) == 1)
        {
          /*******************************************************************/
          /* We have uniqueness.  Update the unique value slot.              */
          /*******************************************************************/
          FIXED_VAL(i,j) = unique_value(i,j);
        }
      }
    }
  }
  return;
}

 void proc_block(int i, int j)
{
  int x;
  int y;
  int k;
  int l;

  /***************************************************************************/
  /* Find the top left-hand corner of the block.                             */
  /***************************************************************************/
  x = (i/3)*3;
  y = (j/3)*3;

  /***************************************************************************/
  /* Wind through each block entry.  If it is fixed then we know that the    */
  /* target entry can't be that value.                                       */
  /***************************************************************************/
  for (k=x; k<(x+BLOCK_SIZE); k++)
  {
    for (l=y; l<(y+BLOCK_SIZE); l++)
    {
      /***********************************************************************/
      /* We're on the next value in the block.                               */
      /***********************************************************************/
      if (((k != i) ||
           (l != j)) &&
           (CAND_COUNT(k,l) == 1))
      {
        if (sudoku[i][j][FIXED_VAL(k,l) - 1] == TRUE)
        {
          /*******************************************************************/
          /* It's a fixed value.  Update the sudoku array thusly.            */
          /*******************************************************************/
          sudoku[i][j][FIXED_VAL(k,l) - 1] = FALSE;

          /*******************************************************************/
          /* Decrement the candidate count.                                  */
          /*******************************************************************/
          CAND_COUNT(i,j)--;

          if (CAND_COUNT(i,j) == 1)
          {
            /*****************************************************************/
            /* We have uniqueness.  Update the unique value slot.            */
            /*****************************************************************/
            FIXED_VAL(i,j) = unique_value(i,j);
          }
        }
      }
    }
  }
  return;
}

 int number_known(void)
{
  int i;
  int j;
  int n = 0;

  for (i=0;i<SIZE;i++)
  {
    for (j=0;j<SIZE;j++)
    {
      if (CAND_COUNT(i,j) == 1)
      {
        /*********************************************************************/
        /* This entry is fixed so increment our count.                       */
        /*********************************************************************/
        n++;
      }
    }
  }

  return n;
}

 int do_check(void)
{
  int i;
  int j;
  int k;
  int x;
  int y;
  int l;
  int success = TRUE;

  for (i=0; i < SIZE; i++)
  {
    for (j=0; j < SIZE; j++)
    {
      /***********************************************************************/
      /* Check whether the entry has run out of candidates.                  */
      /***********************************************************************/
      if (CAND_COUNT(i,j) == 0)
      {
        success = FALSE;
        goto EXIT;
      }

      /***********************************************************************/
      /* Check horizontals for duplicates.  The ordering of the tests is     */
      /* optimized to do the most unlikely ones first.                       */
      /***********************************************************************/
      for (k=0; k < SIZE; k++)
      {
        if ((CAND_COUNT(i,k) == 1) &&
            (CAND_COUNT(i,j) == 1) &&
            (j != k) &&
            (FIXED_VAL(i,k) == FIXED_VAL(i,j)))
        {
          success = FALSE;
          goto EXIT;
        }
      }

      /***********************************************************************/
      /* Check verticals for duplicates.  The ordering of the tests is       */
      /* optimized to do the most unlikely ones first.                       */
      /***********************************************************************/
      for (k=0; k < SIZE; k++)
      {
        if ((CAND_COUNT(k,j) == 1) &&
            (CAND_COUNT(i,j) == 1) &&
            (i != k) &&
            (FIXED_VAL(k,j) == FIXED_VAL(i,j)))
        {
          success = FALSE;
          goto EXIT;
        }
      }

      /***********************************************************************/
      /* Check block containing this entry.  Find the top left-hand corner   */
      /* of the block.                                                       */
      /***********************************************************************/
      x = (i/3)*3;
      y = (j/3)*3;

      /***********************************************************************/
      /* Wind through all entries in the block.                              */
      /***********************************************************************/
      for (k=x; k<(x+BLOCK_SIZE); k++)
      {
        for (l=y; l<(y+BLOCK_SIZE); l++)
        {
          /*******************************************************************/
          /* We're on the next value in the block.  The order of the tests   */
          /* here is optimized to check the most unlikely conditions first.  */
          /*******************************************************************/
          if ((CAND_COUNT(k,l) == 1) &&
              (CAND_COUNT(i,j) == 1) &&
              ((k != i) || (l != j)) &&
              (FIXED_VAL(k,l) == FIXED_VAL(i,j)))
          {
            /*****************************************************************/
            /* Two different entries have been uniquely identified but are   */
            /* the same.  This is a bogus block.  Bail out.                  */
            /*****************************************************************/
            success = FALSE;
            goto EXIT;
          }
        }
      }
    }
  }

EXIT:

  return success;
}

/*****************************************************************************/
/* Prints out the sudoku solution array.                                     */
/*****************************************************************************/
char *
dump()
{
  int i,j;
  char *r,*b;

  r = b = (char *) calloc(1,256);

  *b++ = '[';

  for (i=0;i<SIZE;i++)
  {
    *b++ = '[';
      
    for (j=0;j<SIZE;j++)
    {
      if (CAND_COUNT(i,j) > 1)
        *b++ = '0';
      else
        *b++ = FIXED_VAL(i,j) + '0';

      if(j < SIZE-1) *b++ = ' ';
      
    }
    *b++ = ']';
   
  }
  
  *b++ = ']';
  
  return r;
  
}

/*****************************************************************************/
/* This function returns the unique value that an entry with only one        */
/* candidate has.                                                            */
/*****************************************************************************/
 int unique_value(int x, int y)
{
  int i;
  int output = SIZE+1;

  ASSERT(CAND_COUNT(x,y) == 1);

  for (i=0; i<SIZE; i++)
  {
    if (sudoku[x][y][i] == TRUE)
    {
      output = i+1;
      goto EXIT;
    }
  }

EXIT:

  ASSERT(output < (SIZE+1));

  return (output);
}
