/* ------------------------------------------------------------------ */
/* Decimal Number Library Demonstration program                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) IBM Corporation, 2001, 2003.  All rights reserved.   */
/* ----------------------------------------------------------------+- */
/*                                                 right margin -->|  */

// example1.c -- convert the first two argument words to decNumber,
// add them together, and display the result

#define  DECNUMDIGITS 42           // work with up to 42 digits
#include "decNumber.h"             // base number library
#include <hpgcc49.h>                 // for printf

int main() {
  decNumber a, b;                  // working numbers
  decContext set;                  // working context
  char string[DECNUMDIGITS+14];    // conversion buffer

  unsigned stack = sat_stack_init();
	
  decContextDefault(&set, DEC_INIT_BASE); // initialize
  set.traps=0;                     // no traps, thank you
  set.digits=DECNUMDIGITS;         // set precision

  decNumberFromString(&a, sat_stack_pop_string((char *) malloc(256)), &set);
  decNumberFromString(&b, sat_stack_pop_string((char *) malloc(256)), &set);

  decNumberAdd(&a, &a, &b, &set);            // a=a+b
  decNumberToString(&a, string);

  //printf("%s + %s => %s\n", argv[1], argv[2], string);
  sat_stack_push_string(string);
  
  sat_stack_exit(stack);
	
  return 0;
  } // main
