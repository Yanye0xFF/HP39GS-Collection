//& ****************************************************************************
//&
//& Copyright (C) 2004 HP-GCC Team
//&
//& ****************************************************************************
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//& 
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************



//------------------------------------------------------------------
/** elf2hp.c:
 *
 * \author	Maurin Benjamin
 * \date 25/10/04
 * \version 1.4
 * 
 * Log:\n
 * - 25/10/04 Default to L3/MMU format (Claudio's mmu), modify the -s switch
 * and look for a const global for sysrpl stack size.
 *
 * - 26/08/04 Endian awareness and L3 linker format by Ingo Blank (ibl)
 *
 * - 25/08/04 Use of ELFIO library, .ini file\n
 * Appened a first try for -shared object files. I explain:
 * you can compile with -shared instead of -static, thus
 * producing a CORRECT plt section and a got section TO PATCH
 * during runtime. By patching, I mean translating the addresses
 * and Filling the missing function adresses (given by elf2hp -v)\n
 *
 * - 30/07/04 First public version
 */



#include <bits/c++config.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <unistd.h>
#include <string>
#include <ELFIO.h>



using namespace std;


#define TRUE 1
#define FALSE 0


#define	OLD_GOT_GLOBALS 0
#define	START_GLOBALS 1
#define	NO_GLOBALS 2
#define	MMU_GLOBALS 3

#define STACK_SYMBOL "sys_rpl_mem"


// <ibl ; 2004-11-07>
#define MEMPACKER_RAMBASE 0x09000400
#define RAM_SIGNATURE 0xC00000
unsigned int _ram_signature = RAM_SIGNATURE;
// </ibl>

//! elf ARM symbol entry definition
typedef struct 
{
	int value;
	int size;
	unsigned char bind;	//!<  O= local, 1= global
	int type;		//! 1: variable 2: fct
	char name[255];
} elf_Symbol_Table_Entry;

//! elf ARM relocation entry definition
typedef struct 
{
	int type;
	int offset;
	int value;
	char name[255];
} elf_Relocation_Table_Entry;




//! elf ARM section table definition
typedef struct 
{
	int number;
	char name[20];
	char type[20];
	int address;
	int offset;
	int size;
} elf_Section_Table_Entry;




//! .ini configuration file
/**
 * This must be a text file that looks like this:\n
 * AS=..\bin\arm-elf-as.exe\n
 * ENTRY=_start\n
 * \n
 * There must be at least ONE SPACE between each KEYWORD and = in 'KEYWORD ='
 */
typedef struct
{
	//! Flag to store the endianess of the host
	int bigendian;

	//! path to the executables
	char AS_path[255];
	char GCC_path[255];
	char LD_path[255];
	
	//! Entry point value (string)
	char entry_point[255];

	
	//! Size of the required mem for rpl stuff
	unsigned int rpl_mem_size;

	//! Value of rpl_mem symbol (position in .rodata)
	unsigned int rpl_mem_pos;

	//! choice of arm exe (1) or lib (2)
	int type;
	
	//! choice of the global management
	int global;

	//! choice of the output (L3 format or not)
	int L3_style;
	
	//! Do we add all the functions to the L3 epilog ?
	int L3_full_table;
	
	//! Verbose flag
	/**
	 * Can be changed with -v option
	 */
	int verbose;
	//! Temporary files flag
	/**
	 * Can be changed with -t option
	 */
	int temp_files;
	//! Help requested
	/**
	 * Can be changed with -h option
	 */
	int help;
	//! Name of the arm-elf source
	/**
	 * First filename given on the command file
	 */
	char source[255];
	//! Name of the hp destination
	/**
	 * second filename given on the command file
	 */
	char destination[255];	
}
Configuration;










// Structure of an HP program object
typedef struct
{
	//! size of the text section to skip (plt+text+rodata)
	int text_size;
	//! size of the data_section to copy in RAM (data+dynamic+got)
	int data_size;
	//! size of the bss_section needed in RAM (bss+heap)
	int bss_size;
	//! position of the got_section relative to begining of text
	int got_pos;
	//! relative position of the entry point from begining of .text
	int entry_pos;
	//! GOT table size
	int	got_size ;
	//! dynamic entry flag
	int	dynamic ;

	//! Symbols Table
	elf_Symbol_Table_Entry		*elf_Symbol_Table;	
	//! Size of Symbols Table
	int	elf_Symbol_Table_size;	

	//! Relocation Table
	elf_Relocation_Table_Entry	*elf_Relocation_Table;
	//! Size of Relocation Table
	int	elf_Relocation_Table_size;	
} HP_armobject;






// Structure of an HP arm library
typedef struct
{
	//! size of the text section
	unsigned int text_size;
	//! size of the rodata section
	unsigned int rodata_size;
	//! size of the data_section
	unsigned int data_size;
	//! size of the got_section
	unsigned int got_size;
	//! size of the bss_section+heap
	unsigned int bssheap_size;
	//! relative position of the entry point from begining of .text
	unsigned int entry_pos;
} HP_armlibrary;








//! Definition of a word (4 bytes)
typedef unsigned int USB32;

//! SWAP_B16_IN_B32 - swap 16 bits in 32 bits
/**
 *	dest	- pointer to where the swapped src wil be put
 *	src	- pointer to a 32 bit value to swap
 */
#define SWAP_B16_IN_B32(dest, src) (					\
	*((USB32*)(dest)) =						\
	  (((*((USB32*)(src))) << 16) | ((*((USB32*)(src))) >> 16))	\
)

//! SWAP_B8_IN_B32 - swap 8 & 16 bits in 32 bits
/**
 *	dest	- pointer to where the swapped src wil be put
 *	src	- pointer to a 32 bit value to swap
 *
 * This macro will either switch to the opposite byte sex (Big Endian vs.
 * Little Endian) a 32 bit value.
 */
#define SWAP_B8_IN_B32(dest, src) (					\
	SWAP_B16_IN_B32(dest, src),					\
	(*((USB32*)(dest)) =						\
	  ((((*((USB32*)(dest))) & (USB32)0xff00ff00) >> 8) |		\
	  (((*((USB32*)(dest))) & (USB32)0x00ff00ff) << 8)))		\
)


//! This function checks the endianess of the host
/**
 *
 */
int is_big_endian()
{
	unsigned test = 0xCAFEBABE;
	return  *((unsigned short *) &test) == 0xCAFE;
}



void WriteLD_script(void)
{
	FILE *fp = fopen("elf_ld.script","wb");
	if (fp!=NULL)
	{
fprintf(fp,"\n"
" /* LD SCRIPT MODIFIED BY CLAUDIO AND BENJAMIN \n"
"    GENERATES THE REQUIRED \n"
"    VARIABLES FOR THE LOADER, MOVE THE BASE POINTERS TO \n"
"    0x00000000 FOR READ-ONLY SECTIONS AND 0x09000100 FOR \n"
"    RAM SECTIONS \n"
" */ \n"
"  \n"
"  \n"
"  \n"
" /* Script for -n: mix text and data on same page */ \n"
" OUTPUT_FORMAT(\"elf32-littlearm\", \"elf32-bigarm\", \" \n"
" 	      \"elf32-littlearm\") \n"
" OUTPUT_ARCH(arm) \n"
"  \n"
" /* CHANGE ENTRY POINT TO _loader */ \n"
" ENTRY(_loader) \n"
"  \n"
"  \n"
" SEARCH_DIR(\"c\");  \n"
" SEARCH_DIR(\"/arm-hp/arm-elf/lib\"); \n"
" SEARCH_DIR(\".\");  \n"
"  \n"
" STARTUP(\"MMUloader.o\") \n"
" INPUT(\"MMUglobals.o\") \n"
"  \n"
"  \n"
" SECTIONS \n"
" { \n"
" 	/* CODE SECTIONS START AT 0 BASE ADDRESS */ \n"
"   . = 0 ; \n"
"   __code_start = . ; \n"
"  \n"
"  \n"
" /* all other sections here */ \n"
"   .interp         : { *(.interp) } \n"
"   .hash           : { *(.hash) } \n"
"   .dynsym         : { *(.dynsym) } \n"
"   .dynstr         : { *(.dynstr) } \n"
"   .gnu.version    : { *(.gnu.version) } \n"
"   .gnu.version_d  : { *(.gnu.version_d) } \n"
"   .gnu.version_r  : { *(.gnu.version_r) } \n"
"   .rel.init       : { *(.rel.init) } \n"
"   .rela.init      : { *(.rela.init) } \n"
"   .rel.text       : { *(.rel.text .rel.text.* .rel.gnu.linkonce.t.*) } \n"
"   .rela.text      : { *(.rela.text .rela.text.* .rela.gnu.linkonce.t.*) } \n"
"   .rel.fini       : { *(.rel.fini) } \n"
"   .rela.fini      : { *(.rela.fini) } \n"
"   .rel.rodata     : { *(.rel.rodata .rel.rodata.* .rel.gnu.linkonce.r.*) } \n"
"   .rela.rodata    : { *(.rela.rodata .rela.rodata.* .rela.gnu.linkonce.r.*) } \n"
"   .rel.data       : { *(.rel.data .rel.data.* .rel.gnu.linkonce.d.*) } \n"
"   .rela.data      : { *(.rela.data .rela.data.* .rela.gnu.linkonce.d.*) } \n"
"   .rel.tdata	  : { *(.rel.tdata .rel.tdata.* .rel.gnu.linkonce.td.*) } \n"
"   .rela.tdata	  : { *(.rela.tdata .rela.tdata.* .rela.gnu.linkonce.td.*) } \n"
"   .rel.tbss	  : { *(.rel.tbss .rel.tbss.* .rel.gnu.linkonce.tb.*) } \n"
"   .rela.tbss	  : { *(.rela.tbss .rela.tbss.* .rela.gnu.linkonce.tb.*) } \n"
"   .rel.ctors      : { *(.rel.ctors) } \n"
"   .rela.ctors     : { *(.rela.ctors) } \n"
"   .rel.dtors      : { *(.rel.dtors) } \n"
"   .rela.dtors     : { *(.rela.dtors) } \n"
"   .rel.got        : { *(.rel.got) } \n"
"   .rela.got       : { *(.rela.got) } \n"
"   .rel.bss        : { *(.rel.bss .rel.bss.* .rel.gnu.linkonce.b.*) } \n"
"   .rela.bss       : { *(.rela.bss .rela.bss.* .rela.gnu.linkonce.b.*) } \n"
"   .rel.plt        : { *(.rel.plt) } \n"
"   .rela.plt       : { *(.rela.plt) } \n"
"   .init           : \n"
"   { \n"
"     KEEP (*(.init)) \n"
"   }  \n"
"   .plt            : { *(.plt) } \n"
"   .text           : \n"
"   { \n"
"     *(.text .stub .text.* .gnu.linkonce.t.*) \n"
"     /* .gnu.warning sections are handled specially by elf32.em.  */ \n"
"     *(.gnu.warning) \n"
"     *(.glue_7t) *(.glue_7) \n"
"   }  \n"
"   .fini           : \n"
"   { \n"
"     KEEP (*(.fini)) \n"
"   }  \n"
"  \n"
"  \n"
" /* CREATE VARIABLES */ \n"
"  \n"
"   __got_start = .; \n"
"  \n"
" /* MOVE THE .GOT TABLE TO A POSITION BEFORE THE ACTUAL DATA */ \n"
"   .got      0x09000100  : AT(__got_start) \n"
"    \n"
"    { *(.got.plt) *(.got) } \n"
"  \n"
"   __got_size = . - 0x09000100; \n"
"  \n"
"   __data_start = . - 0x09000100 + __got_start; \n"
"  \n"
"   __tmp_datastart = . ; \n"
"  \n"
"   .rodata : { *(.rodata .rodata.* .gnu.linkonce.r.*) } \n"
"   .rodata1        : { *(.rodata1) } \n"
"   .eh_frame_hdr : { *(.eh_frame_hdr) } \n"
"  \n"
"  \n"
"   .preinit_array     : { *(.preinit_array) } \n"
"   PROVIDE (__preinit_array_end = .); \n"
"   PROVIDE (__init_array_start = .); \n"
"   .init_array     : { *(.init_array) } \n"
"   PROVIDE (__init_array_end = .); \n"
"   PROVIDE (__fini_array_start = .); \n"
"   .fini_array     : { *(.fini_array) } \n"
"   PROVIDE (__fini_array_end = .); \n"
"  \n"
" 	. = ALIGN(4); \n"
"  \n"
"   .data   :  \n"
"   { \n"
"   \n"
"     *(.data .data.* .gnu.linkonce.d.*) \n"
"     SORT(CONSTRUCTORS) \n"
"   } \n"
" /* OUTPUT THE SIZE OF THE DATA SEGMENT */ \n"
"   __data_size = . - __tmp_datastart; \n"
"  \n"
" /* NO NEED TO COPY THE BSS SECTION, BUT OBTAIN THE SIZE */ \n"
"  \n"
"   __bss_start = .; \n"
"  \n"
"   .bss  : \n"
"   { \n"
"    *(.dynbss) \n"
"    *(.bss .bss.* .gnu.linkonce.b.*) \n"
"    *(COMMON) \n"
"    /* Align here to ensure that the .bss section occupies space up to \n"
"       _end.  Align after .bss to ensure correct alignment even if the \n"
"       .bss section disappears because there are no input sections.  */ \n"
"    . = ALIGN(32 / 8); \n"
"   } \n"
"   . = ALIGN(32 / 8); \n"
"   _end = .; \n"
"  \n"
"  /* CREATE VARIABLE _bss_size */ \n"
"   \n"
"   __bss_size = SIZEOF( .bss ); \n"
"  \n"
"  \n"
"   .data1          : { *(.data1) } \n"
"   .tdata	  : { *(.tdata .tdata.* .gnu.linkonce.td.*) } \n"
"   .tbss		  : { *(.tbss .tbss.* .gnu.linkonce.tb.*) *(.tcommon) } \n"
"  \n"
"  \n"
"   .eh_frame       : { KEEP (*(.eh_frame)) } \n"
"   .gcc_except_table   : { *(.gcc_except_table) } \n"
"   .dynamic        : { *(.dynamic) } \n"
"   .ctors          : \n"
"   { \n"
"     /* gcc uses crtbegin.o to find the start of \n"
"        the constructors, so we make sure it is \n"
"        first.  Because this is a wildcard, it \n"
"        doesn't matter if the user does not \n"
"        actually link against crtbegin.o; the \n"
"        linker won't look for a file to match a \n"
"        wildcard.  The wildcard also means that it \n"
"        doesn't matter which directory crtbegin.o \n"
"        is in.  */ \n"
"     KEEP (*crtbegin*.o(.ctors)) \n"
"     /* We don't want to include the .ctor section from \n"
"        from the crtend.o file until after the sorted ctors. \n"
"        The .ctor section from the crtend file contains the \n"
"        end of ctors marker and it must be last */ \n"
"     KEEP (*(EXCLUDE_FILE (*crtend*.o ) .ctors)) \n"
"     KEEP (*(SORT(.ctors.*))) \n"
"     KEEP (*(.ctors)) \n"
"   } \n"
"   .dtors          : \n"
"   { \n"
"     KEEP (*crtbegin*.o(.dtors)) \n"
"     KEEP (*(EXCLUDE_FILE (*crtend*.o ) .dtors)) \n"
"     KEEP (*(SORT(.dtors.*))) \n"
"     KEEP (*(.dtors)) \n"
"   } \n"
"   .jcr            : { KEEP (*(.jcr)) } \n"
"  \n"
"  \n"
"  \n"
"  \n"
"   PROVIDE (end = .); \n"
"   /* Stabs debugging sections.  */ \n"
"   .stab          0 : { *(.stab) } \n"
"   .stabstr       0 : { *(.stabstr) } \n"
"   .stab.excl     0 : { *(.stab.excl) } \n"
"   .stab.exclstr  0 : { *(.stab.exclstr) } \n"
"   .stab.index    0 : { *(.stab.index) } \n"
"   .stab.indexstr 0 : { *(.stab.indexstr) } \n"
"   .comment       0 : { *(.comment) } \n"
"   /* DWARF debug sections. \n"
"      Symbols in the DWARF debugging sections are relative to the beginning \n"
"      of the section so we begin them at 0.  */ \n"
"   /* DWARF 1 */ \n"
"   .debug          0 : { *(.debug) } \n"
"   .line           0 : { *(.line) } \n"
"   /* GNU DWARF 1 extensions */ \n"
"   .debug_srcinfo  0 : { *(.debug_srcinfo) } \n"
"   .debug_sfnames  0 : { *(.debug_sfnames) } \n"
"   /* DWARF 1.1 and DWARF 2 */ \n"
"   .debug_aranges  0 : { *(.debug_aranges) } \n"
"   .debug_pubnames 0 : { *(.debug_pubnames) } \n"
"   /* DWARF 2 */ \n"
"   .debug_info     0 : { *(.debug_info .gnu.linkonce.wi.*) } \n"
"   .debug_abbrev   0 : { *(.debug_abbrev) } \n"
"   .debug_line     0 : { *(.debug_line) } \n"
"   .debug_frame    0 : { *(.debug_frame) } \n"
"   .debug_str      0 : { *(.debug_str) } \n"
"   .debug_loc      0 : { *(.debug_loc) } \n"
"   .debug_macinfo  0 : { *(.debug_macinfo) } \n"
"   /* SGI/MIPS DWARF 2 extensions */ \n"
"   .debug_weaknames 0 : { *(.debug_weaknames) } \n"
"   .debug_funcnames 0 : { *(.debug_funcnames) } \n"
"   .debug_typenames 0 : { *(.debug_typenames) } \n"
"   .debug_varnames  0 : { *(.debug_varnames) } \n"
"     .stack         0x80000 : \n"
"   { \n"
"     _stack = .; \n"
"     *(.stack) \n"
"   } \n"
"   .note.gnu.arm.ident 0 : { KEEP (*(.note.gnu.arm.ident)) } \n"
"   /DISCARD/ : { *(.note.GNU-stack) } \n"
" } \n"
"  \n"
);
	}
	fclose(fp);
}




int Cat_Binary(char *src_name1, char *src_name2, char *dest_name)
{
	char buffer;
	FILE *fp_src = fopen(src_name1,"rb");
	if (fp_src!=NULL)
	{
		FILE *fp_dest = fopen(dest_name,"wb");
		if (fp_dest!=NULL)
		{
			while( (!feof(fp_src)) && fread(&buffer,1,1,fp_src))
				fwrite(&buffer,1,1,fp_dest);
			
			fclose(fp_src);
			fp_src = fopen(src_name2,"rb");
			if (fp_src!=NULL)
			{
				while( (!feof(fp_src)) && fread(&buffer,1,1,fp_src))
					fwrite(&buffer,1,1,fp_dest);
				fclose(fp_src);
			}
			else
			{
				printf("Read error, Cat_binary can't open %s",src_name2);
				exit(0);
			}
			fclose(fp_dest);
		}
		else
		{
			printf("Write error, Cat_binary can't open %s",dest_name);
			fclose(fp_src);
			exit(0);
		}
	}
	else
	{
		printf("Read error, Cat_binary can't open %s",src_name1);
		exit(0);
	}
	return(1);
}











string
SectionTypes( Elf32_Word type )
{
    string sRet = "UNKNOWN";
    switch ( type ) {
    case SHT_NULL :
        sRet = "NULL";
        break;
    case SHT_PROGBITS :
        sRet = "PROGBITS";
        break;
    case SHT_SYMTAB :
        sRet = "SYMTAB";
        break;
    case SHT_STRTAB :
        sRet = "STRTAB";
        break;
    case SHT_RELA :
        sRet = "RELA";
        break;
    case SHT_HASH :
        sRet = "HASH";
        break;
    case SHT_DYNAMIC :
        sRet = "DYNAMIC";
        break;
    case SHT_NOTE :
        sRet = "NOTE";
        break;
    case SHT_NOBITS :
        sRet = "NOBITS";
        break;
    case SHT_REL :
        sRet = "REL";
        break;
    case SHT_SHLIB :
        sRet = "SHLIB";
        break;
    case SHT_DYNSYM :
        sRet = "DYNSYM";
        break;
    }
    
    return sRet;
}


string SectionFlags( Elf32_Word flags )
{
    string sRet = "";
    if ( flags & SHF_WRITE ) {
        sRet += "W";
    }
    if ( flags & SHF_ALLOC ) {
        sRet += "A";
    }
    if ( flags & SHF_EXECINSTR ) {
        sRet += "X";
    }

    return sRet;
}



void		PrintSymbol( std::string& name, Elf32_Addr value,
				Elf32_Word size,
				unsigned char bind, unsigned char type,
				Elf32_Half section )
{
	printf( "%-34.34s %08x %08x %04x %04x %04x\n",
		name.c_str(),
		(unsigned int)value,
		(unsigned int)size,
		(int)bind,
		(int)type,
		section );
}


void		PrintSection( int i, const IELFISection* pSec )
{
	printf( "  [%2x] %-20s %-8.8s %08x %06x %02x %-3.3s %02x %04x %02x\n",
		i,
		string( pSec->GetName() ).substr( 0, 20 ).c_str(),
		SectionTypes( pSec->GetType() ).c_str(),
		(unsigned int)pSec->GetAddress(),
		(unsigned int)pSec->GetSize(),
		(unsigned int)pSec->GetEntrySize(),
		SectionFlags( pSec->GetFlags() ).c_str(),
		(unsigned int)pSec->GetLink(),
		(unsigned int)pSec->GetInfo(),
		(unsigned int)pSec->GetAddrAlign()
		);
}












/**
 *	Verify the Elf header, check if it is ELF32 little endian
 */
int VerifyHeader( const IELFI* pReader, HP_armobject *hpobject, Configuration *_config)
{
	// fill default values for the object
	hpobject->got_pos = -1;
	
	// Check class:
	if ( pReader->GetClass() != ELFCLASS32 )
	{
		printf("ELFIO: Wrong CLASS32, got %d\n",(int)pReader->GetClass());
		return(0);
	}
	if (_config->verbose)
	{
		printf( "\nVerifying ELF header:\n" );
		printf( "---------------------\n" );
		printf( "  Class:      %s (%d)\n",
			( pReader->GetClass() == ELFCLASS32 ) ? "CLASS32" : "Unknown",
			(int)pReader->GetClass() );
	}
	
	if ( pReader->GetEncoding() != ELFDATA2LSB )
	{
		if ( pReader->GetEncoding() == ELFDATA2MSB )
			printf( "  Encoding:   Big endian, but require little endian\n" );
		else
			printf( "  Encoding:   Unknown, require little endian\n" );
		return(0);
	}
	
	if (_config->verbose)		printf( "  Encoding:   Little endian\n" );
	
	
	// Fill the dynamic field
	if (pReader->GetType()==2)
		hpobject->dynamic = 0;
	else if (pReader->GetType()==3)
		hpobject->dynamic = 1;
	
	if (_config->verbose)
	{
		printf( "  ELFVersion: %s (%d)\n",
			( EV_CURRENT == pReader->GetELFVersion() ) ? "Current" : "Unknown",
			(int)pReader->GetELFVersion() );
		if (pReader->GetType()==2)
			printf( "  Type:       EXEC\n");
		else if (pReader->GetType()==3)
			printf( "  Type:       DYN\n");
		else printf( "  Type:       0x%04X\n",   pReader->GetType() );
		printf( "  Version:    0x%08X\n",   (unsigned int)pReader->GetVersion() );
		printf( "  Flags:      0x%08X\n", (unsigned int)pReader->GetFlags() );
	}

	// Check machine compatibility
	if (pReader->GetMachine() != 0x28)		//=ARM-ELF
	{
		printf( "  Machine type incompatible:    0x%04X\n",   pReader->GetMachine() );
		return(0);
	}
	if (_config->verbose)	printf( "  Machine:    0x%04X\n",   pReader->GetMachine() );
	

	// Fill entry point
	hpobject->entry_pos = pReader->GetEntry();
	if (_config->verbose)	printf( "  Entry:      0x%08X\n",   hpobject->entry_pos );


	return(1);
}











//! Fill elf symbol table
/**
 * 
 */
void Fill_Elf_Symbol_Table(IELFI* pReader, HP_armobject *hpobject, Configuration *_config)
{

	int i;
	// First count all the symbols (scan the sections for that)

	int _section,_symbol,_relocation;
	int skip_empty = 1;

	if (_config->verbose)
	{
		printf( "\nLook for ELF symbol section(s):\n" );
		printf( "-------------------------------\n" );
		if (skip_empty) printf( "Empty name symbols are skipped.\n" );
	}
	
	//Initialize symbol table size:
	hpobject->elf_Symbol_Table_size = 0;
	hpobject->elf_Relocation_Table_size = 0;
	
	// Scan the sections to count the total number of symbols
	for ( _section = 0; _section < pReader->GetSectionsNum(); _section++ )
	{
		const IELFISection* pSec = pReader->GetSection( _section );
		// Symbol table
		if ( (pSec->GetType() == SHT_SYMTAB) || (pSec->GetType()==SHT_DYNSYM) )
		{
			IELFISymbolTable* pSymTbl = 0;
			pReader->CreateSectionReader( IELFI::ELFI_SYMBOL, pSec, (void**)&pSymTbl );
			
			int _nbsymbols = pSymTbl->GetSymbolNum();
			
			if (_nbsymbols>0)
			{
				hpobject->elf_Symbol_Table_size+=_nbsymbols;
				if (_config->verbose) printf( "Numbers of symbols in %s: %d\n",
					pSymTbl->GetName().c_str(),_nbsymbols);
			}
			pSymTbl->Release();
		}
		
		if ( SHT_REL == pSec->GetType() || SHT_RELA == pSec->GetType() ) 
		{
			IELFIRelocationTable* pRel = 0;
			pReader->CreateSectionReader( IELFI::ELFI_RELOCATION, pSec, (void**)&pRel );
			
			int _nbsymbols = pRel->GetEntriesNum();
			if (_nbsymbols>0)
			{
				hpobject->elf_Relocation_Table_size+=_nbsymbols;
				if (_config->verbose) printf( "Numbers of relocations in %s: %d\n",
					pRel->GetName().c_str(),_nbsymbols);
			}
			pRel->Release();
		}
		
		pSec->Release();
	}
	
	hpobject->elf_Symbol_Table = (elf_Symbol_Table_Entry*)malloc(sizeof(elf_Symbol_Table_Entry)*hpobject->elf_Symbol_Table_size);
	_symbol = 0;
	
	if ( (hpobject->elf_Relocation_Table_size>0) && (hpobject->dynamic==0) )
	{
		printf("Warning: Static object relocation information present.\n");
	}
	if ( (hpobject->elf_Relocation_Table_size==0) && (hpobject->dynamic==1) )
	{
		printf("Warning: Shared object but no relocation information.\n");
	}
	hpobject->elf_Relocation_Table = (elf_Relocation_Table_Entry*)malloc(sizeof(elf_Symbol_Table_Entry)*hpobject->elf_Relocation_Table_size);
	_relocation = 0;
	
	// Scan the sections to store the symbols
	for ( _section = 0; _section < pReader->GetSectionsNum(); _section++ )
	{
		const IELFISection* pSec = pReader->GetSection( _section );
		if ( (pSec->GetType() == SHT_SYMTAB) || (pSec->GetType()==SHT_DYNSYM) )
		{
			IELFISymbolTable* pSymTbl = 0;
			pReader->CreateSectionReader( IELFI::ELFI_SYMBOL, pSec, (void**)&pSymTbl );
			
			std::string   name;
			Elf32_Addr    value;
			Elf32_Word    size;
			unsigned char bind;
			unsigned char type;
			Elf32_Half    section;
			
			int _nbsymbols = pSymTbl->GetSymbolNum();
			
			if (_nbsymbols>0)
			{
				if (_config->verbose)
				{
					printf( "In Symbol table (%s)\n", pSymTbl->GetName().c_str() );
					printf( "  Id:      Name                          Value    Size     Bind Type Sect\n" );
				}
				for ( int i = 0; i < _nbsymbols; i++ )
				{
					pSymTbl->GetSymbol( i, name, value, size, bind, type, section );
					
					if ((strlen(name.c_str())==0) && skip_empty) continue;
					
					if (_config->verbose)
					{
						printf("%04d: ",i);
						PrintSymbol( name, value, size, bind, type, section );
					}
					strcpy(hpobject->elf_Symbol_Table[_symbol].name, name.c_str());
					hpobject->elf_Symbol_Table[_symbol].bind = bind;
					hpobject->elf_Symbol_Table[_symbol].value = value;
					hpobject->elf_Symbol_Table[_symbol].size = size;
					hpobject->elf_Symbol_Table[_symbol].type = type;
					_symbol++;
					
				}
			}
			pSymTbl->Release();
		}
		
		//Relocation symbols:
		if ( SHT_REL == pSec->GetType() || SHT_RELA == pSec->GetType() ) 
		{
			IELFIRelocationTable* pRel = 0;
			pReader->CreateSectionReader( IELFI::ELFI_RELOCATION, pSec, (void**)&pRel );
			
			// Print all entries
			Elf32_Addr     offset;
			Elf32_Addr     symbolValue;
			std::string    symbolName;
			unsigned char  type;
			Elf32_Sword    addend;
			Elf32_Sword    calcValue;
			int nNum = pRel->GetEntriesNum();
			
			if ( nNum>0 )
			{
				if (_config->verbose)
				{
					printf( "\nSection name: %s\n", pSec->GetName().c_str() );
					printf( "  Num Type Offset   Addend    Calc   SymValue   SymName\n" );
				}
				for ( int i = 0; i < nNum; i++ )
				{
					pRel->GetEntry( i, offset, symbolValue, symbolName,
							type, addend, calcValue );
					
					if ((strlen(symbolName.c_str())==0) && skip_empty) continue;
					if (_config->verbose)
					{
						if (type==0x16) // R_ARM_JUMP_SLOT
						{
							std::printf( "[%4x] JUMP %08x %08x %08x %08x %s\n",
								i, (unsigned int)offset,
								(unsigned int)addend, (unsigned int)calcValue,
								(unsigned int)symbolValue, symbolName.c_str()
								);
						}
						else if (type==0x15) // R_ARM_GLOB_DAT
						{
							std::printf( "[%4x] GLOB %08x %08x %08x %08x %s\n",
								i, (unsigned int)offset,
								(unsigned int)addend, (unsigned int)calcValue,
								(unsigned int)symbolValue, symbolName.c_str()
								);
						}
						else // Unknown
						{
							std::printf( "[%4x] %02x %08x %08x %08x %08x %s\n",
								i, type, (unsigned int)offset,
								(unsigned int)addend, (unsigned int)calcValue,
								(unsigned int)symbolValue, symbolName.c_str()
								);
						}
					}

					strcpy(hpobject->elf_Relocation_Table[_relocation].name, symbolName.c_str());
					hpobject->elf_Relocation_Table[_relocation].type = type;
					hpobject->elf_Relocation_Table[_relocation].value = symbolValue;
					hpobject->elf_Relocation_Table[_relocation].offset = offset;
					_relocation++;

				}
			}
		}

		
		pSec->Release();
	}
	hpobject->elf_Symbol_Table_size = _symbol;
	hpobject->elf_Symbol_Table = (elf_Symbol_Table_Entry*)realloc(hpobject->elf_Symbol_Table,sizeof(elf_Symbol_Table_Entry)*hpobject->elf_Symbol_Table_size);

	if (_config->verbose) printf("\nLooking for entry point %s\n",_config->entry_point);
	hpobject->entry_pos = -1;
	
	// Find functions and entry function
	for(i=0; i<hpobject->elf_Symbol_Table_size; i++)
	{
		if (strcmp(hpobject->elf_Symbol_Table[i].name, _config->entry_point)==0)
		{
			if (hpobject->entry_pos != -1) 
			{
				printf("Error: Two or more %s() functions, check if you link"
				" with crt0.o\n", _config->entry_point);
				exit(1);
			}
			hpobject->entry_pos = hpobject->elf_Symbol_Table[i].value;
			if (_config->verbose)
				printf("%s entry found at offset"
				" %x\n",_config->entry_point, hpobject->entry_pos);
		}
		
		if (strcmp(hpobject->elf_Symbol_Table[i].name, STACK_SYMBOL)==0)
		{
			_config->rpl_mem_pos = hpobject->elf_Symbol_Table[i].value;
			if (_config->verbose)
				printf("Found rpl mem size symbol at: %x\n",_config->rpl_mem_pos);
		}
	}
	printf("\n");
	if (hpobject->entry_pos == -1)
	{
		printf("Error: no %s() functions, check if you link with crt0.o\n", 
		_config->entry_point);
		exit(1);
	}
}







//! Copy elf section table
/**
 * Scan the sections and copy them to an output file.
 */
int Make_Binary_Word_Aligned_Sections(IELFI *pReader, HP_armobject *hpobject, char *_dest_name,  Configuration *_config)
{
	// Open output binary file
	FILE *fp = fopen(_dest_name,"wb");
	if (fp==NULL)
	{
		printf("Can't create file %s.\n",_dest_name);
		return(0);
	}
	
	if (_config->verbose)
	{
		printf( "Copying binary sections:\n" );
		printf( "------------------------\n" );
		printf( "Section headers:\n" );
		printf( "  [Nr] Name                 Type     Addr     Size   ES Flg Lk Inf  Al\n" );
	}

	// Flag to know if we have to append the section to the output
	int _copy_flag;
	// If dynamic, then this variable stores plt_offset
	int plt_offset = 0;
	
	int _section = 0;
	unsigned int i;
	
	// reset size values:
	hpobject->text_size = 0;
	hpobject->data_size = 0;
	hpobject->got_size = 0;
	hpobject->got_pos = -1;
	
	//now scan the sections:
	for ( _section = 0; _section < pReader->GetSectionsNum(); _section++ ) 
	{
		const IELFISection* pSec = pReader->GetSection( _section );

		if (_config->verbose) PrintSection( _section, pSec );
		
		
		// Now look if we have to add this section to the output:
		_copy_flag = 0;
		
		if ((strcmp(pSec->GetName().c_str(),".plt")==0)&&(hpobject->dynamic==1))
		{
			//this section has to be altered since
			//it points to a constant position of the
			//got table (which will not be the case in the
			//futur)
			hpobject->text_size += pSec->GetSize();
			plt_offset = pSec->GetAddress();
			hpobject->entry_pos -= plt_offset;
			_copy_flag = 1;
		}
		
		if (strcmp(pSec->GetName().c_str(),".text")==0)
		{
			//create the binary files (word aligned)
			hpobject->text_size += pSec->GetSize();
			_copy_flag = 1;
		}
		
		if (strcmp(pSec->GetName().c_str(),".got")==0)
		{
			hpobject->data_size += pSec->GetSize();
			hpobject->got_pos = pSec->GetAddress();
			hpobject->got_size = pSec->GetSize();
			
			//Required by Claudio's new loader
			if (hpobject->got_pos==MEMPACKER_RAMBASE) 
			{
				if (_config->rpl_mem_size==0xfffff)
					_config->rpl_mem_size=_ram_signature;
				else
					_config->rpl_mem_size+=_ram_signature;
				
				if (_config->verbose)
					printf("GOT section at %x, use new RPL mem size %x\n",MEMPACKER_RAMBASE, _config->rpl_mem_size);
			}
			
			//LOTS of things to do here !
			if (hpobject->dynamic==1)
			{
				
				if (_config->verbose)
					printf("Section Patched,%d bytes\n", (int)pSec->GetSize());
				
				//Because it's a dynamic shared object, we
				//build our own got table based on offsets
				//given in relocation table:

				int *_data = (int*) malloc(sizeof(int)*(pSec->GetSize()/4));
				if (_data==0) exit(0);
				
				//We write into a temporary buffer (_data)
				//the corrected values of known relocations
				for(i=0;i<(unsigned int)hpobject->elf_Relocation_Table_size; i++)
				{
					int pos_in_got = hpobject->elf_Relocation_Table[i].offset-hpobject->got_pos;
					if (hpobject->elf_Relocation_Table[i].value != 0)
					{
						_data[pos_in_got/4] = hpobject->elf_Relocation_Table[i].value-plt_offset;
					}
					else
						_data[pos_in_got/4] = 0;
					if (_config->verbose)
					{
						printf("Symbol %s written with value %08X, at adress"
						"%08Xof got\n",
						hpobject->elf_Relocation_Table[i].name,
						_data[pos_in_got/4],pos_in_got );
					}
					if (_data[pos_in_got/4] == 0)
					{
						printf("The symbol '%s'\t written with value %08X,"
						" at offset %08X of GOT:\n"
						"  HAS TO BE RELOCATED AT RUNTIME.\n",
						hpobject->elf_Relocation_Table[i].name,
						_data[pos_in_got/4],pos_in_got );
					}
				}
				
				//Now we copy the content to the file:
				fwrite(_data,hpobject->got_size,1,fp);
				
				free(_data);
				hpobject->got_pos-=plt_offset;
			}
			else
				_copy_flag = 1;
			
			
		}
		
		if (strcmp(pSec->GetName().c_str(),".rodata")==0)
		{			
			//create the binary files (word aligned)
			hpobject->text_size += pSec->GetSize();
			// Look for a specific value in the section
			if (_config->rpl_mem_pos > 0)
			{
				char *_data = (char*) pSec->GetData();
				_config->rpl_mem_size = _data[_config->rpl_mem_pos-pSec->GetAddress()];

				if (_config->verbose)
					printf("RPL mem size from symbol: %d\n",_config->rpl_mem_size);
					
				if (hpobject->got_pos==MEMPACKER_RAMBASE) 
				{
					if (_config->rpl_mem_size==0xfffff)
						_config->rpl_mem_size=_ram_signature;
					else
						_config->rpl_mem_size+=_ram_signature;
					if (_config->verbose)
						printf("GOT section at %x, use new RPL mem size %x\n",MEMPACKER_RAMBASE, _config->rpl_mem_size);
				}
			}
			_copy_flag = 1;
		}
		
		if (strcmp(pSec->GetName().c_str(),".data")==0)
		{
			hpobject->data_size += pSec->GetSize();
			_copy_flag = 1;
		}
		
		if ((strcmp(pSec->GetName().c_str(),".dynamic")==0)&&(hpobject->dynamic==1))
		{
			// This has to be removed once we achieved to
			// alter the .plt section (change the values inside)
			hpobject->data_size += pSec->GetSize();
			_copy_flag = 1;
		}
				
		if (strcmp(pSec->GetName().c_str(),".bss")==0)
		{
			
			hpobject->data_size += pSec->GetSize();
			if (_config->global!=3)
			{
				if (_config->verbose)
				printf("Section created, added %d cleared "
				"bytes\n",(int)pSec->GetSize());
				// Create .bss section:
				for(i=0;i<pSec->GetSize();i++)
					fwrite("\0",1,1,fp);
			}
		}
		/*
		if (strcmp(pSec->GetName().c_str(),".stack")==0)
		{
			unsigned int s = _config.mem_size;

			if (s==0) s = pSec->GetSize();
			
			hpobject->data_size += s;
			
			// Append .stack section:
			for(i=0;i<s;i++)
				fwrite("\0",1,1,fp);
		}
		*/
		
		if (_copy_flag)
		{
			if (_config->verbose)
				printf("Section added,%d bytes\n", (int)pSec->GetSize());
			
			char *_data = (char*) pSec->GetData();
			
			fwrite(_data,pSec->GetSize(),1,fp);
			
			// Append a few byte if not word aligned
			if ((pSec->GetSize()%4)!=0)
			{
				if (_config->verbose)
					printf("Padding %d bytes to section:%s\n",
						(int)(4-(pSec->GetSize()%4)),
						pSec->GetName().c_str());
				
				for(i=0; i<(4-(pSec->GetSize()%4)); i++)
					fwrite("\0",1,1,fp);
			}
		}
		pSec->Release();
	}
	//printf( "Key to Flags: W (write), A (alloc), X (execute)\n\n" );
	fclose(fp);
	return(1);

}





//! Call the assembler to build the start code that does GOT relocation for globals
/**
 * In this start code, the A>CP (subpl r3,r3,r1,asr #28 instruction)
 * is inserted at the beginning. This code use r2, r3, r4 to compute
 * the relative offset between PC (program counter) and the GOT location.
 * It then stores the result in SL (R10 register) and call the entry point.
 *
 * 
 */
int Build_Start_Code(char *name, HP_armobject *hpobjet, Configuration *_config)
{
	char buffer[512];
	if (_config->verbose)
	{
		printf( "\nBuilding binary loader in tmp_conv_bin.o:\n" );
		printf( "-----------------------------------------\n" );
	}
	
	
	if (_config->global== OLD_GOT_GLOBALS)
	{
		//Build the start code:
		FILE *fp_start = fopen("tmp_conv.s","wb");
		fprintf(fp_start,"\t.text\n");
		fprintf(fp_start,"\t.align\t1\n");
		fprintf(fp_start,"\tstmfd\tsp!, {r0, r1, r2, r3,"
		" r4, r5, r6, r7, r8, r9, r10, r11, r12, lr}\n");	//Save flags
		if (hpobjet->got_size>0)
		{
			fprintf(fp_start,"\tldr\tsl, [pc, #4]\n");		// sl=position got
			fprintf(fp_start,"\tldr\tr2, [pc, #4]\n");		// r2=taille got
			fprintf(fp_start,"\tB\t12\n");					// saut des constantes
			fprintf(fp_start,"\t.word\t%d\n",hpobjet->got_pos+4*17);	//Position got
			fprintf(fp_start,"\t.word\t%d\n",hpobjet->got_size-4);	// Taille got
			fprintf(fp_start,"\tadd\tsl, sl, pc\n");		// sl=sl+pc (debut got)
			fprintf(fp_start,"\tsub\tsl, sl, #28\n"); 		// sl=debut got (ajustement)
			fprintf(fp_start,"\tadd\tr3, r2, sl\n"); 		// r3=fin got
			fprintf(fp_start,"\tldr\tr4, [r3]\n");			// repeat: r3=derniere ligne got
			fprintf(fp_start,"\tadd\tr4, r4, pc\n");		// r3=r3+pc
			fprintf(fp_start,"\tadd\tr4, r4, #24\n");		// r3+=24 (ajustement)
			fprintf(fp_start,"\tstr\tr4, [r3]\n");			// stocke r4 en r3
			fprintf(fp_start,"\tsub\tr2, r2, #4\n");		// remonte d'une ligne

			fprintf(fp_start,"\tcmp\tr2, #0\n");			// while(not end of got)
			fprintf(fp_start,"\tbne\t-28\n");				// go back
		}
		fprintf(fp_start,"\tBL\t %d\n",hpobjet->entry_pos+4*2); // Go to entry point
		fprintf(fp_start,"\tldmfd\tsp!, {r0, r1, r2, r3,"
		" r4, r5, r6, r7, r8, r9, r10, r11, r12, pc }\n"); // Restore flags

		fclose(fp_start);

		// Call assembler
		sprintf(buffer, "%s -EL -mcpu=arm920t -mapcs-32 -k tmp_conv.s -o tmp_conv.o ",_config->AS_path);
		if (_config->verbose)
		{
			printf( "Calling assembler:\n%s\n",buffer);
		}

		FILE *pipe;
		pipe = popen(buffer,"r");
		while( (!feof(pipe)) && (fgets(buffer,255,pipe)))
		{
			printf("%s\n",buffer);
		}
		pclose(pipe);
		
		// Get .text section
		IELFI* pReader;
		if ( ERR_ELFIO_NO_ERROR != ELFIO::GetInstance()->CreateELFI( &pReader ) )
		{
			printf( "Can't create ELF reader\n" ); return(0);
		}
		if ( ERR_ELFIO_NO_ERROR != pReader->Load( "tmp_conv.o" ) )
		{
			printf( "Can't open input file tmp_conv.o\n"); return(0);
		}

		//Write text section in 'name'
		// Open output binary file
		FILE *fp = fopen(name,"wb");
		if (fp==NULL)
		{
			printf("Can't create file %s.\n",name);
			return(0);
		}

		int _section = 0;
		unsigned int i;
		//now scan the sections for .text
		for ( _section = 0; _section < pReader->GetSectionsNum(); _section++ ) 
		{
			const IELFISection* pSec = pReader->GetSection( _section );
			if (strcmp(pSec->GetName().c_str(),".text")==0)
			{
				//create the binary files (word aligned)
				fwrite((char*)pSec->GetData(),pSec->GetSize(),1,fp);

				// Append a few byte if not word aligned
				if ((pSec->GetSize()%4)!=0)
				{
					for(i=0; i<(4-(pSec->GetSize()%4)); i++)
						fwrite("\0",1,1,fp);
				}
			}
			pSec->Release();
		}
		fclose(fp);

		if (!_config->temp_files) unlink("tmp_conv.s");
		if (!_config->temp_files) unlink("tmp_conv.o");
	
	}
	else if (_config->global==START_GLOBALS)
	{
		//Write text section in 'name'
		// Open output binary file
		FILE *fp = fopen(name,"wb");
		if (fp==NULL)
		{
			printf("Can't create file %s.\n",name);
			return(0);
		}
		// write SAVE REG
		sprintf(buffer,"%c%c%c%c",
			0xff,0x5f,0x2d,0xe9); //stmdn		sp!,{r0-r12,lr}
		fwrite(buffer,4,1,fp);
		if (_config->verbose) printf("%02X %02X %02X %02X\n",0xff,0x5f,0x2d,0xe9);
		
		//write BRANCH main()
		// Compute BL offset:
		int offset =
			(0xffffff+(hpobjet->entry_pos)/4)%0xffffff;
		unsigned char c;
		c=((unsigned char*)&offset)[0];
		fwrite(&c,1,1,fp);
		if (_config->verbose) printf("%02X ",c);
		c=((unsigned char*)&offset)[1];
		fwrite(&c,1,1,fp);
		if (_config->verbose) printf("%02X ",c);
		c=((unsigned char*)&offset)[2];
		fwrite(&c,1,1,fp);
		if (_config->verbose) printf("%02X ",c);
		
		c = 0xeb;	//BL main()
		fwrite(&c,1,1,fp);
		if (_config->verbose) printf("%02X\n",c);
		
		// write RESTORE REGS
		sprintf(buffer,"%c%c%c%c",
			0xff,0x9f,0xbd,0xe8); //ldmfd		sp!,{r0r-12,pc}
		fwrite(buffer,4,1,fp);
		if (_config->verbose) printf("%02X %02X %02X %02X\n",0xff,0x9f,0xbd,0xe8);
		fclose(fp);
	}
	else if (_config->global==NO_GLOBALS)
	{
		if (_config->verbose)
		{
			printf("No code added, empty file produced.\n");
			if (_config->L3_style)
				printf("L3 is chosen, the first entry in the table is the entry point\n");
		}
		FILE *fp = fopen(name,"wb");
		if (fp==NULL)
		{
			printf("Can't create file %s.\n",name);
			return(0);
		}
		fclose(fp);
	}
	else if (_config->global==MMU_GLOBALS)
	{
		// start code is provided by Claudio's loader:

		// Write a blank _start code
		FILE *fp = fopen(name,"wb");
		if (fp==NULL)
		{
			printf("Can't create file %s.\n",name);
			return(0);
		}
		fclose(fp);
	}
	else 
	{
		printf("Internal error\n");
	}
	
	return(1);
}




//! Encapsulate an ARM object
/**
 * If -c option is used, then the output is of L3 format.
 * Moreover, if -C is used instead of -c, then the L3 format is filled
 * with a table containing ALL the global functions of the Elf file.
 * Remember that the A>CP code is always put since it is
 * hard-coded inside the start code.
 * \see Build_Start_Code
 */
int Append_Header(char *src_name, char *dest_name,  HP_armobject *hpobject, Configuration *_config)
{
	if (_config->verbose)
	{
		printf( "\nConverting arm binary to required format (A>CP or L3):\n" );
		printf( "--------------------------------------------------------\n" );
	}
	FILE *fp_src;
	fp_src=fopen(src_name,"rb");
	if (fp_src==NULL)
	{
		printf("Cannot open %s file for input\n",src_name);
		return(0);
	}
	FILE *fp_dest;
	fp_dest=fopen(dest_name,"wb");
	if (fp_dest==NULL)
	{
		printf("Cannot open %s file for output\n",dest_name);
		fclose(fp_src);
		return(0);
	}

	unsigned char c;
	
	if (_config->L3_style)
	{
		if (_config->verbose) printf("L3 chosen.\n");
		
		// (ibl)  Write the L3 magic header (prolog)
		c = 0x4C;
		fwrite(&c,1,1,fp_dest);
		c = 0xB3;
		fwrite(&c,1,1,fp_dest);
		c = 0x80;
		fwrite(&c,1,1,fp_dest);
	}
	else if (_config->verbose) printf("A>CP default.\n");
	
	char * ACP="A>CP";
	// Write A>CP in all cases
	fwrite(ACP,4,1,fp_dest);
	
	// write the ARM binary
	while( (!feof(fp_src)) && (fread(&c,1,1,fp_src)))
		fwrite(&c,1,1,fp_dest);
	
	if (_config->L3_style)
	{
		unsigned v;
		unsigned nb_fct=0;
		unsigned offset;
		unsigned address;

		if (_config->global==OLD_GOT_GLOBALS)
			offset = 72; // size of compiled start code
		else if (_config->global==START_GLOBALS)
			offset = 12; // size of compiled small start code
		else
			offset = 0;
			
		
		if (_config->L3_full_table)
		{
			if (_config->verbose) 
				printf("Full table added (Warning, RAM=0 for all).\n");
			
			// Find functions and append them
			for(int i=0; i<hpobject->elf_Symbol_Table_size; i++)
			{
				//Check if symbol is a global function:
				if ((hpobject->elf_Symbol_Table[i].bind==1)&&
					(hpobject->elf_Symbol_Table[i].type==2))
				{
					// amount of ram for this function
					// UNKOWN ??
					v = 0;
					fwrite(&v,sizeof(unsigned),1,fp_dest);
					// Address of function:
					address = hpobject->elf_Symbol_Table[i].value+offset;
					v = _config->bigendian ?SWAP_B8_IN_B32(&v,&address) : address;
					fwrite(&v,sizeof(unsigned),1,fp_dest);
					
					if (_config->verbose) 
					printf("%-34.34s(%08X) added to L3"
						" table\n",hpobject->elf_Symbol_Table[i].name,address);
					
					nb_fct++;
				}
			}
		}
		if (_config->verbose) printf("%d functions added to L3 table\n",nb_fct);
		//Finally, add the entry point end epilog:
		//number of entry points:
		v = _config->bigendian ? SWAP_B8_IN_B32(&v,&nb_fct) : nb_fct;
		fwrite(&v,sizeof(unsigned),1,fp_dest);


		// This should be	0x000FFFFF for all RAM (old Claudio's mmu)
		// This should be	0x00400000 for all RAM (new Claudio's mmu)
		v = _config->bigendian ? SWAP_B8_IN_B32(&v,&_config->rpl_mem_size) : _config->rpl_mem_size;
		fwrite(&v,sizeof(unsigned),1,fp_dest);
		
		unsigned epilog[] = 
		{
			0x00000000,
			0x00000000,
			0x3176B34C
		};
		if (_config->global>=2)
		{
			epilog[0] = hpobject->entry_pos;
		}
		int epilog_size = sizeof(epilog)/sizeof(unsigned);
		// (ibl) Write L3 epilog 
		for (int i = 0; i < epilog_size; i++) 
		{
			v = _config->bigendian ? SWAP_B8_IN_B32(&v,&epilog[i]) : epilog[i];
			fwrite(&v,sizeof(unsigned),1,fp_dest);
		}
	}


	// close files
	fclose(fp_dest);
	fclose(fp_src);
	return(1);
}



//! Encapsulate a binary object into a HP49 string
/**
 * Endianess is used to write the proper size value (IBL).
 */
int Convert_HP49_String(char *src_name, char *dest_name,  HP_armobject *hpobject, Configuration *_config)
{
	if (_config->verbose)
	{
		printf( "\nConverting object to HP49 string:\n" );
		printf( "-----------------------------------\n" );
	}
	FILE *fp_src;
	fp_src=fopen(src_name,"rb");
	if (fp_src==NULL)
	{
		printf("Cannot open %s file for input\n",src_name);
		return(0);
	}
	
	FILE *fp_dest;
	unsigned int size=0;
	unsigned char c;
	char buffer[255];
	
	// Compute the file size to write the HP's string header
	while( (!feof(fp_src)) && (fread(&c,1,1,fp_src)))
		size++;
	rewind(fp_src);
	
	if (_config->verbose) printf("Code size:%d\n",size);
	
	fp_dest=fopen(dest_name,"wb");
	if (fp_dest==NULL)
	{
		printf("Cannot open %s file for output\n",dest_name);
		fclose(fp_src);
		return(0);
	}
	
	
	unsigned int octets=0;
	
	// Write HP's string header
	strcpy(buffer,"HPHP49-C");
	fwrite(buffer,strlen(buffer),1,fp_dest);
	c=0x2c;
	if (_config->verbose>1) printf("%02X",c);
	fwrite(&c,1,1,fp_dest);
	c=0x2a;
	if (_config->verbose>1) printf("%02X",c);
	fwrite(&c,1,1,fp_dest);
	
	// write the string size:
	// 2*size: since 1 char=2 nibbles
	// +5: for string size part (5nibbles)

	unsigned int nibbles, nibbles_ = (2*size+5)<<4;	

	// (ibl) swap words, if necessary
	if (_config->bigendian) 
		SWAP_B8_IN_B32(&nibbles,&nibbles_);
	else
		nibbles = nibbles_;


	c=((unsigned char*)&nibbles)[0];
	if (_config->verbose>1) printf("%02X",c);
	fwrite(&c,1,1,fp_dest);
	c=((unsigned char*)&nibbles)[1];
	if (_config->verbose>1) printf("%02X",c);
	fwrite(&c,1,1,fp_dest);
	c=((unsigned char*)&nibbles)[2];
	if (_config->verbose>1) printf("%02X \n",c);
	fwrite(&c,1,1,fp_dest);
	
	
	// copy the file, bytes by bytes
	while( (!feof(fp_src)) && (fread(&c,1,1,fp_src)))
	{
		if (_config->verbose>1) printf("%02X ",c);
		fwrite(&c,1,1,fp_dest);
		octets++;
		if ((octets%4==0)&&(_config->verbose>1)) printf("\t");
		if ((octets%16==0)&&(_config->verbose>1)) printf("\n");
	}
	
	// close output file
	fclose(fp_dest);
	if (_config->verbose)
		printf("\nConversion successfull to %s (%d bytes)\n",
			dest_name,
			octets);
	fclose(fp_src);
	return(1);
}









//!Parse command line arguments
/**
 *
 */
void Arg_Check(int argc,char **argv, Configuration *_config)
{
	int i,j,files=0;

	// Give some defaults:
	_config->rpl_mem_size = 0xfffff;
	_config->global = MMU_GLOBALS;
	_config->L3_style = TRUE;
	_config->L3_full_table = FALSE;
	_config->verbose = FALSE;
	_config->temp_files = FALSE;
	strcpy(_config->entry_point,"_loader");
	_config->rpl_mem_pos = 0;
	
						
	for(i=1; i<argc; i++)
	{
		// Look if we have an option:
		if (argv[i][0]=='-')
		{

			//then which one
			for(j=1;argv[i][j]!='\0';j++)
			{

				switch(argv[i][j])
				{
					case 'v':
						_config->verbose = 1;
						if (isdigit(argv[i][j+1]))
							_config->verbose = argv[i][j+1]-'0';
						break;
						
					case 't':
						_config->temp_files = 1;
						break;
						
					case 'h':
			printf("elf2hp utility v1.4 (M.B. 2004): take an elf and convert it to a L3 HP string\n"
			"Usage: elf2hp [-vtlhacmM] [-s<xxx>] [-e<foo>] a.exe a.hp\n\n"
			" Made for HP-GCC. Guidelines when compiling:\n"
			" -------------------------------------------\n"
			" 1. use gcc for arm with at least:\n\t-mapcs-32 -fpic -msingle-pic-base"
			" -mpic-register=r10 -mlittle-endian\n"
			" 2. use ld for mmu-arm with at least:\n\t-T ld.script ../lib/crt0.o \n"
			" 3. use elf2hp with:\n\tprog.exe prog.hp\n\n"
			" Options are:\n"
			" -e<foo> force entry point to be <foo>\n"
			" -s<xxx> give SysRPL block size in bytes (default is 0)\n"
			" -n Don't use System memory\n"
			" -m use a minimal start code (as required, GOT/globals managed inside the code)\n"
			" -M don't use a start code (no as required, GOT/globals not managed)\n"
			" -c don't use Claudio's ARM Toolbox L3-style (A>CP, output smaller)\n"
			" -a append full functions to the L3 table\n"
			" -v verbose output\n"
			" -t keep tempory files\n"
			" -l to write ld.script in current dir (Warning ld.script subject to modifications)\n"
			" -h show help\n");
						exit(0);
						break;
					case 'l':
						printf("Writing ld.script in current dir...\n");
						WriteLD_script();
						exit(0);
					case 'm':
						_config->global = OLD_GOT_GLOBALS;
						break;
					case 'M':
						_config->global = NO_GLOBALS;
						break;
					case 'c':
						_config->L3_style = FALSE;
						break;
					case 'k':
						break;
					case 'a':
						_config->L3_full_table = TRUE;
						break;
					case 'e':
						strcpy(_config->entry_point,argv[i]+j+1);
						if (_config->verbose)
							printf("Entry point forced to: %s\n",_config->entry_point);
						j=strlen(argv[i])-1;
						break;
					case 's':
						_config->rpl_mem_size = atoi(argv[i]+j+1);
						if (_config->verbose)
							printf("RPL Mem fixed to: %d\n",_config->rpl_mem_size);
						j=strlen(argv[i])-1;
						break;
						
					case 'n':
						//< ibl; 2004-11-07 >
						// Don't use system memory
						_ram_signature &= 0x7FFFFF; // 0xCmmmmm -> 0x4mmmmm
						break;
					
					default:
						printf("Option unknown:%c\n",argv[i][j]);
						break;
				}
			}
		}
		else
		{
			switch(files)
			{
				case 0:
					strcpy(_config->source,argv[i]);
					files=1;
					break;
				case 1:
					strcpy(_config->destination,argv[i]);
					files=2;
					break;
				default:
					printf("Warning, no more than 2 namefiles should be given\n");
					printf("%s is unused.\n",argv[i]);
			}
		}
	}
	if (files!=2)
	{
		printf("Error, not enough arguments were given. Need 2 filenames.\n");
		printf("Try elf2hp -h.\n");
		exit(0);
	}
}


//! Returns 1 if not empty
int Check_Empty_String(char *str)
{
	int r=1;
	while(*str)
	{
		r=r&&(!isspace(*str));
		str++;
	}
	return(r);
}



//!Load configuration file
/**
 *
 */
void Load_Conf_File(Configuration *_config)
{
	char buffer[255],keyword[255], value[255];
	FILE *fp;

	strcpy( _config->GCC_path, "");
	strcpy( _config->AS_path, "");
	strcpy( _config->LD_path, "");
										
	// Look for the configuration file
	fp=fopen("elf2hp.ini", "r");
	if (fp!=NULL)
	{
		while( (!feof(fp)) && (fgets(buffer,255,fp)))
		{
			if (strlen(buffer)!=0)
				if (buffer[0]!='#')
				{
					sscanf(buffer, "%s =%s\n", keyword, value);
					if (Check_Empty_String(keyword)&&Check_Empty_String(value))
					{
						if (strcmp(keyword,"AS")==0)
							strcpy(_config->AS_path,value);
						if (strcmp(keyword,"GCC")==0)
							strcpy(_config->GCC_path,value);
						if (strcmp(keyword,"LD")==0)
							strcpy(_config->LD_path,value);
						if ((strcmp(keyword,"ENTRY")==0) && (strcmp(_config->entry_point,"_loader")==0))
							strcpy(_config->entry_point, value);
					}
				}
		}
		fclose(fp);
	}
	// Else look for the defaults to use:
	else
	{
		if (_config->verbose)
			printf("Initialization file (elf2hp.ini) not found! Defaults are"
			" used.\n");
			
		int asm_found = 0;
		char buffer[255];
		char prefix[255]="arm-elf-";
		char postfix[255]="";
		
		FILE *pipe;
		// try  "arm-elf-as.exe --version"
		pipe = popen("arm-elf-as.exe --version","r");
		while( (!feof(pipe)) && (fgets(buffer,255,pipe)))
		{
			if (strncmp(buffer,"GNU assembler",13)==0)
			{
				strcpy( prefix, "arm-elf-");
				strcpy( postfix, ".exe");
				strcpy( _config->AS_path, "arm-elf-as.exe");
				if (_config->verbose) printf("Found assembler: %s\n",buffer);
				asm_found = 1;
			}
			//if (_config->verbose) printf("%s\n",buffer);
		}
		pclose(pipe);
		
		if (asm_found == 0)
		{
			// try  "arm-elf-as --version"
			pipe = popen("arm-elf-as --version","r");
			while( (!feof(pipe)) && (fgets(buffer,255,pipe)))
			{
				if (strncmp(buffer,"GNU assembler",13)==0)
				{
					strcpy( prefix, "arm-elf-");
					strcpy( postfix, "");
					strcpy( _config->AS_path, "arm-elf-as");
					if (_config->verbose) printf("Found assembler: %s\n",buffer);
					asm_found = 1;
				}
				//if (_config->verbose) printf("%s\n",buffer);
			}
			pclose(pipe);

			if (asm_found == 0)
			{
				// try  "arm-linux-as --version"
				pipe = popen("arm-linux-as --version","r");
				while( (!feof(pipe)) && (fgets(buffer,255,pipe)))
				{
					if (strncmp(buffer,"GNU assembler",13)==0)
					{
						strcpy( prefix, "arm-linux-");
						strcpy( postfix, "");
						strcpy( _config->AS_path, "arm-linux-as");
						if (_config->verbose) printf("Found assembler: %s\n",buffer);
						asm_found = 1;
					}
					//if (_config->verbose) printf("%s\n",buffer);
				}
				pclose(pipe);

				if (asm_found == 0)
				{
					if (_config->verbose)
						printf("No default assembler found, check your installation"
						" of GNU AS or the PATH variable\n");
					// remove next line
					//exit(0);
				}
			}
		}

		if (strlen(_config->GCC_path)==0)
		{
			strcpy( _config->GCC_path, prefix);
			strcat( _config->GCC_path, "gcc");
			strcat( _config->GCC_path, postfix);
		}
		if (strlen(_config->AS_path)==0)
		{
			strcpy( _config->AS_path, prefix);
			strcat( _config->AS_path, "as");
			strcat( _config->AS_path, postfix);
		}
		if (strlen(_config->LD_path)==0)
		{
			strcpy( _config->LD_path, prefix);
			strcat( _config->LD_path, "ld");
			strcat( _config->LD_path, postfix);
		}
	}
	
	if (_config->verbose)
	{
		printf("AS =%s\n",_config->AS_path);
		printf("LD =%s\n",_config->LD_path);
		printf("GCC =%s\n",_config->GCC_path);
		printf("ENTRY =%s\n",_config->entry_point);
	}
}










/**
 * Main() of convert program
 *
 * Purpose of this tool is to convert binary ARM to a HP string that
 * can be loaded using HP Connectivity software and lunched using ARM launcher.bin ("A>CP" version).
 */
int main(int argc,char **argv)
{

	// Object containing the configuration of elf2hp
	Configuration config;

	// Object containing the arm-hp code configuration
	HP_armobject hpobject;

	// (ibl) determine endianess
	config.bigendian = is_big_endian();
	
	// Check arguments
	Arg_Check(argc, argv, &config);
	
	// load conf file
	Load_Conf_File(&config);

	
	
	// Open ELF reader
	IELFI* pReader;
	if ( ERR_ELFIO_NO_ERROR != ELFIO::GetInstance()->CreateELFI( &pReader ) )
	{
		printf( "Can't create ELF reader\n" );
		return 2;
	}
	
	if ( ERR_ELFIO_NO_ERROR != pReader->Load( config.source ) )
	{
		printf( "Can't open input file \"%s\"\n", config.source );
		return 3;
	}
	
	// Verify ELF file header
	if (!VerifyHeader( pReader, &hpobject, &config ))
	{
		printf("Error during arm-elf verification\n");
		return(1);
	}


	// Fill ELF symbol table first
	Fill_Elf_Symbol_Table( pReader, &hpobject,&config );
	
	// Fill ELF section table
	if (!Make_Binary_Word_Aligned_Sections(pReader, &hpobject, "tmp_conv.armbin",&config))
	{
		exit(0);
	}

	if (!Build_Start_Code("tmp_conv.start",&hpobject,&config))
	{
		exit(0);
	}
	
	pReader->Release();
	
	Cat_Binary("tmp_conv.start","tmp_conv.armbin","tmp_conv.hpbin");
	
	Append_Header("tmp_conv.hpbin", "tmp_conv.hea", &hpobject,&config);
	
	Convert_HP49_String("tmp_conv.hea",config.destination, &hpobject, &config);
	
	if (hpobject.elf_Symbol_Table) free(hpobject.elf_Symbol_Table);
	if (hpobject.elf_Relocation_Table) free(hpobject.elf_Relocation_Table);
	
	if (!config.temp_files) unlink("tmp_conv.start");
	if (!config.temp_files) unlink("tmp_conv.hpbin");
	if (!config.temp_files) unlink("tmp_conv.hea");
	if (!config.temp_files) unlink("tmp_conv.armbin");

	return(0);
}

