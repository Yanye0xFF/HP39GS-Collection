#include <hpgcc49.h>
#include <hpgraphics.h>
#include <win.h>

int clear_event, a_event, b_event, exit_event;
win_widget_t *menu, *label, *field, *check;
win_widget_t *slider1, *slider2, *slider3, *slider4;

int set(void *event_data, void *app_data)
{
    win_text_set_text(field, (char *) app_data);
    return 1;
}

int doexit(void *event_data, void *app_data)
{
    win_event_quit();
    return 1;
}

int main(void)
{

    win_init();

    clear_event = win_register_event();
    a_event = win_register_event();
    b_event = win_register_event();
    exit_event = win_register_event();

    menu = win_softmenu_new();
    win_softmenu_set_item(menu, 0, "CLEAR", clear_event, NULL);
    win_softmenu_set_item(menu, 1, "A", a_event, NULL);
    win_softmenu_set_item(menu, 2, "B", b_event, NULL);
    win_softmenu_set_item(menu, 5, "EXIT", exit_event, NULL);

    label = win_text_new_label("Text:");
    field = win_text_new_entry(10);

    win_widget_set_location(label, 0, 0);
    win_widget_set_location(field, 24, 0);

    check = win_checkbox_new("Testing");
    win_widget_set_location(check, 75, 0);
    win_checkbox_set_menu(check, menu, 3);

    slider1 = win_progress_new(1);
    win_progress_set_orient(slider1, WIN_PROGRESS_HORIZ);
    win_widget_set_location(slider1, 0, 10);
    win_widget_set_size(slider1, 80, 5);

    slider2 = win_progress_new(1);
    win_progress_set_orient(slider2, WIN_PROGRESS_VERT);
    win_widget_set_location(slider2, 20, 20);
    win_widget_set_size(slider2, 5, 40);

    slider3 = win_progress_new(1);
    win_progress_set_orient(slider3, WIN_PROGRESS_VERT_TOP);
    win_widget_set_location(slider3, 60, 20);
    win_widget_set_size(slider3, 5, 40);

    slider4 = win_progress_new(1);
    win_progress_set_orient(slider4, WIN_PROGRESS_HORIZ_RIGHT);
    win_widget_set_location(slider4, 0, 65);
    win_widget_set_size(slider4, 80, 5);

    win_add_event_handler(clear_event, 0, set, "");
    win_add_event_handler(a_event, 0, set, "A");
    win_add_event_handler(b_event, 0, set, "B");
    win_add_event_handler(exit_event, 0, doexit, NULL);

    win_add_widget(menu);
    win_add_widget(label);
    win_add_widget(field);
    win_add_widget(check);
    win_add_widget(slider1);
    win_add_widget(slider2);
    win_add_widget(slider3);
    win_add_widget(slider4);

    win_event_loop();
    return 0;
}

