#include <hpgcc49.h>

void clearScreen()
{
	// clears the HP49g+'s screen

   kos_ClearLcd(); //use the OS call

}
