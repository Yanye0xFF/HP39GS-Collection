//& ****************************************************************************
//&
//& Written by Al Borowski, September 2004
//& 
//& Copyright (C) 2004 The HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

#include <hpkeyb49.h>
#include <hpctype.h>


char __keys49[]={ //keymap of a HP49 keyboard

8, //0 (backspace)
'P', //1
'O', //2
'N', //3
'M', //4
'A', //5
0, //6 (UP)
'K', //7
0, //8
0, //9

0, //10
0, //11
0, //12
0, //13
0, //14
0, //15
'U', //16
'T', //17
'S', //18
'R', //19

'Q', //20
'B', //21
0, //22
'L', //23
0, //24
0, //25
0, //26
0, //27
0, //28
0, //29

0, //30
0, //31
'Z', //32
'Y', //33
'X', //34
'W', //35
'V', //36
'C', //37
0, //38
0, //39

0, //40
0, //41
0, //42
0, //43
0, //44
0, //45
0, //46
0, //47
'*', //48
'9', //49

'8', //50
'7', //51
0, //52
'D', //53
0, //54
0, //55
0, //56
0, //57
0, //58
0, //59

0, //60
0, //61
0, //62
0, //63
'-', //64
'6', //65
'5', //66
'4', //67
0, //68
'E', //69

'H', //70
0, //71
0, //72
0, //73
0, //74
0, //75
0, //76
0, //77
0, //78
0, //79

'+', //80
'3', //81
'2', //82
'1', //83
0, //84
'F', //85
'I', //86
0, //87
0, //88
0, //89

0, //90
0, //91
0, //92
0, //93
0, //94
0, //95
10, //96 (enter)
' ', //97 (space)
'.', //98
'0', //99

0, //100
'G', //101
'J', //102
0, //103
0, //104
0, //105
0, //106
0, //107
0, //108
0 //109

};



char getchar(){ //reads a character from the keyboard
					//returns the ASCII keycode for the character
					
	int keycode = keyb_getkey(1); //get the keycode for the next key

	char * keytab = __keys49; //hardwired to 49 keymap for now

	char key = keytab[keycode&0xff]; //disregarding the modifier keys, lookup the right character

	//now, if the left shift was pressed, convert any alpha char to lower case

	if((keycode>>10)&1) key=tolower(key);

	return key;
}

