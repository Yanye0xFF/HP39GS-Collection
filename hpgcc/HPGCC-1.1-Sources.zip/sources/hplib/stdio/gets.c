//copyright junk goes here (mainly GPL stuff)

#include <hpgcc49.h>

static void backTrack(){ //moves the cursor back one position

	int x=getx();//get the current cursor position
	int y=gety(); 
		
	if((x==0)&&(y==0)) return; //already at start
		
	if(x==0){ //cursor is current at the start of a line - need to move it back one
		
		x=screen_width()-1; //move to end of previous line
		y--;
			
	}
	
	else x--; //otherwise just move back a character

	gotoxy(x,y); //move to the new position

	return;
}


char* gets(char *buffer){ //gets function

	int i=0; //offset into buffer
	char key;

	while(1){

		key= getchar(); //read in a character
		
		if(key==10) break; //newline, we're done
		
		if((key!=0)&&(key!=8)){ //valid character
		
			buffer[i]=key; //save it
			putchar(key); //and display it
			i++;
		}
		
		if(key==8){ //backspace key was hit
		
			if(i!=0){ //if we have not gone back too far
				i--; //move back a position in the buffer
				backTrack(); //and on-screen
				putchar(' '); //erase the previous character
				backTrack(); //position over the space
			}
		}
		
	}
	buffer[i]=0; //write null terminator
	return buffer;

}
