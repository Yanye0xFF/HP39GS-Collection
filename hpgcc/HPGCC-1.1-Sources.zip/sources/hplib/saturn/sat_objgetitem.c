//& <prolog>
//& ****************************************************************************
//&
//& Written by Ingo Blank & Claudio Lapilli
//&
//& Copyright (C) 2005 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/hplib/saturn/sat_objgetitem.c,v 1.3 2005/05/18 19:27:25 iblank Exp $

#include <hpgcc49.h>





/*! \brief
// RETURN POINTER TO THE ITEM THAT CONTAINS THE OBJECT
// IF THE OBJECT IS IN A DIRECTORY
// RETURNS -1 IF NOT IN USEROB
// IF EMBEDDED WITHIN AN OBJECT, RETURNS THE ITEM
// OF THE PARENT OBJECT, BUT NEGATIVE TO INDICATE IT
// IS NOT THE ADDRESS OF THE REQUESTED OBJECT
*/

int 
sat_objgetitem(int objptr)
{
	int home=sat_peek(SAT_USEROB,5);
	int diritem=sat_dirfindfirst(sat_dirhome()),objstart,objend;
	
	// HOME is empty
	if(diritem<0) return -1;
	
	int endhome=sat_skipob(sat_sknameup(diritem));
	
	// CHECK IF OBJECT IS IN USEROB
	if(objptr<=home || objptr >=endhome) return -1;
	
	do {
		if(diritem<0) return -1;
		
		objstart=sat_sknameup(diritem);
		objend=sat_skipob(objstart);
		if(objptr==objstart) return diritem;
		
		if(objptr>objstart && objptr<objend) {
			
			// OBJECT IS EMBEDDED WITHIN THE OBJECT
			if(sat_peek(objstart,5)==SAT_DORRP) {
				// SEARCH IN THE INNER DIRECTORY
				diritem=sat_dirfindfirst(sat_objgetdir(objstart));
				continue;
			}
			else 
				// EMBEDDED IN AN OBJECT OTHER THAN AN RRP
				return -diritem;
	
		}
		diritem=sat_dirfindnext(diritem);
		
	} while(diritem>=0);
	
	// IMPOSSIBLE TO REACH THIS POINT UNLESS MEMORY IS CORRUPTED
	
	return -1;

}


