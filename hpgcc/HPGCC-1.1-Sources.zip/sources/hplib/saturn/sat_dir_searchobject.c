//& <prolog>
//& ****************************************************************************
//&
//& Written by Ingo Blank & Claudio Lapilli
//&
//& Copyright (C) 2005 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/hplib/saturn/sat_dir_searchobject.c,v 1.4 2005/05/18 19:27:25 iblank Exp $

#include <hpgcc49.h>





/*!
	\fn		int sat_dir_searchobject(char *name,SAT_DIR_SLIST **res)
	\brief	Search for object named \b "name" down the whole directory tree.
	\return	The number of found objects and a result set (string list) \b res, containing the full paths
*/

int
_sat_dir_searchobject(char *name, SAT_DIR_NODE *p, SAT_DIR_SLIST **res)
{
	
	int count = 0;
	
	while (p) {
		
		SAT_DIR_ENTRY *q;
		int dif;
		
		dif = 1;
		q = p->object;
		
		while (q && (dif = strcmp(q->sat_obj->name,name)))
			q = q->next;
		
		if (!dif) { // HIT
			
			SAT_DIR_SLIST *s;
			char *t,*r;
			
			sys_chkptr(s = (SAT_DIR_SLIST *) malloc(sizeof(SAT_DIR_SLIST)));
			r = _sat_dir_path(p);
			sys_chkptr(t = (char *) malloc(strlen(r)+strlen(name)+2));
			strcpy(t,r);
			strcat(t,"/");
			s->str = strcat(t,name);
			s->next = *res;
			*res = s;
			count++;
			free(r);
			
		}
		
		count += _sat_dir_searchobject(name, p->child, res);
		
		p = p->sibling;
	}
	
	return count;
}

int
sat_dir_searchobject(char *name,SAT_DIR_SLIST **res)
{

	*res = NULL;
	return _sat_dir_searchobject(name,_sat_dir_getroot(),res);
}


