#include <hpgcc49.h>

//type checks a stack type
//returns TRUE if an object exists at the specificed stack level,
//and matches type 'prologue'

//returns FALSE otherwise

//First version, al borowski, 5/5/05



int sat_check_type(unsigned int level, unsigned int prologue){

	if(level==0) return FALSE; //error - checking level 0!
	
	if (sat_stack_depth()<level) return FALSE; //error - not not enough items on the stack

	SAT_STACK_ELEMENT element; //the element on the stack
	sat_get_stack_element(1,&element); //get the details
	if(element.prologue!=prologue) return FALSE; //types don't match
	
	return TRUE; //they match
	 
}
