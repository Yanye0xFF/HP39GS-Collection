//& <prolog>
//& ****************************************************************************
//&
//& Written by Ingo Blank & Claudio Lapilli
//&
//& Copyright (C) 2005 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/hplib/saturn/sat_skipob.c,v 1.3 2005/05/18 19:27:25 iblank Exp $

#include <hpgcc49.h>





#define STBL(prolog,size) (prolog + (size << 20))

#define SAT_TOTALOBJECTS 34

// TABLE TO SKIP OBJECTS
unsigned int __skipobtbl[SAT_TOTALOBJECTS]={

// FIXED-SIZE OBJECTS
	STBL(SAT_DOBINT,10),
	STBL(SAT_DOREAL,21),
	STBL(SAT_DOEREL,26),
	STBL(SAT_DOCMP,37),
	STBL(SAT_DOECMP,47),
	STBL(SAT_DOCHAR,7),
	STBL(SAT_DOROMP,11),
	STBL(SAT_DOFLASHP,12),

// LIST-LIKE OBJECTS
	STBL(SAT_DOLIST,0xFF),
	STBL(SAT_DOCOL,0xFF),
	STBL(SAT_DOEXT,0xFF),
	STBL(SAT_DOMATRIX,0xFF),
	STBL(SAT_DOSYMB,0xFF),

// IDNT-LIKE OBJECTS
	STBL(SAT_DOIDNT,0xFE),
	STBL(SAT_DOLAM,0xFE),

// SIZE-SKIPPABLE
	STBL(SAT_DOARRY,0xFD),
	STBL(SAT_DOBAK,0xFD),
	STBL(SAT_DOCODE,0xFD),
	STBL(SAT_DOCSTR,0xFD),
	STBL(SAT_DOGROB,0xFD),
	STBL(SAT_DOHXS,0xFD),
	STBL(SAT_DOINT,0xFD),
	STBL(SAT_DOLNKARRY,0xFD),
	STBL(SAT_DOLIB,0xFD),
	STBL(SAT_DOEXT0,0xFD),
	STBL(SAT_DOEXT1,0xFD), 	   // COULD BE WRONG - ACPTR IS PROBABLY A FIXED-SIZE OBJECT
	STBL(SAT_DOEXT2,0xFD),
	STBL(SAT_DOEXT3,0xFD),
	STBL(SAT_DOEXT4,0xFD),
	STBL(SAT_DOLNGCOMP,0xFD),  // PROBABLY FIXED SIZE, BUT APPARENTLY UNUSED?
	STBL(SAT_DOLNGREAL,0xFD),  // PROBABLY FIXED SIZE, BUT APPARENTLY UNUSED?
	STBL(SAT_DOAPLET,0xFD),    // MIGHT BE WRONG

// SPECIAL OBJECTS
	STBL(SAT_DORRP,0xFC),
	STBL(SAT_DOTAG,0xFB)
};



int 
sat_skipob(int obaddr)
{
	int *tbl=__skipobtbl;
	int item;
	register int f,prolog,value;

	prolog=sat_peek(obaddr,5);

	for(f=0;f<SAT_TOTALOBJECTS;++f)
	
		if( ((value=tbl[f])&0xfffff)==prolog ) {
	
			value>>=20;
			switch(value)
			{
			case 0xfb:
				// DOTAG OBJECTS
				return sat_skipob( sat_sknameup(obaddr+5)-2);
	
			case 0xfc:
				// DIRECTORIES
				obaddr=sat_objgetdir(obaddr);
				item=sat_dirfindfirst(obaddr);
				if(item<0) return obaddr+5;
				return sat_skipob(sat_sknameup(item));
	
			case 0xfd:
				// SIZE-SKIPPABLE OBJECTS
				obaddr+=5;
				return obaddr+sat_peek(obaddr,5);
	
			case 0xfe:
				// IDNT-LIKE OBJECTS
				obaddr+=5;
				return obaddr+((sat_peek(obaddr,2)+1)<<1);
	
			case 0xff:
				// LIST-LIKE OBJECTS
				obaddr+=5;
				while(sat_peek(obaddr,5)!=SAT_SEMI)
				{
					obaddr=sat_skipob(obaddr);
				}
				return obaddr+5;
	
			default:
				return obaddr+value;
			}
		}
	

	// SKIP ROM POINTERS
	return obaddr+5;

}


