//& <prolog>
//& ****************************************************************************
//&
//& Written by Ingo Blank & Claudio Lapilli
//&
//& Copyright (C) 2005 HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

//& </prolog>

// $Header: /cvsroot/hpgcc/sources/hplib/saturn/sat_dir_open.c,v 1.3 2005/05/18 19:27:25 iblank Exp $

#include <hpgcc49.h>





SAT_DIR_NODE *__sat_cwd,*__sat_root;

/*!	
	\fn 	static void _sat_dir_scan(SAT_DIR_NODE *root, int dirobj)
	\brief	Recursively walk the Saturn directory tree
			and build the internal data structures
*/

// DON'T CALL EXPLICITLY!

static void
_sat_dir_scan(SAT_DIR_NODE *root, int dirobj)
{
	int h=sat_objgetdir(dirobj);
	int item=sat_dirfindfirst(h),obj,prolog;
	char name[256];
	
	if(h == sat_dirhome()) 
		strcpy(name,"HOME");
	else 
		sat_itemgetname(sat_objgetitem(dirobj),name);
	
	
	while(item != -1) {
		
		sat_itemgetname(item,name);
		obj=sat_sknameup(item);
		prolog=sat_peek(obj,5);
		
		if (prolog == SAT_DORRP) { // sub-directory

			SAT_DIR_NODE *p;
			
			sys_chkptr(p = (SAT_DIR_NODE *) calloc(1,sizeof(SAT_DIR_NODE)));
			p->name = strdup(name);
			p->sibling = root->child;
			root->child = p;
			p->parent = root;
			if (sat_objgetdir(obj) == sat_dircurrent()) 
				__sat_cwd = p;
			_sat_dir_scan(p,obj);
			
		}
		else { // simple object

			SAT_DIR_ENTRY *p;
			SAT_OBJ_DSCR  *d;
			
			sys_chkptr(p = (SAT_DIR_ENTRY *) calloc(1,sizeof(SAT_DIR_ENTRY)));
			sys_chkptr(d = (SAT_OBJ_DSCR *) calloc(1,sizeof(SAT_OBJ_DSCR)));
			
			d->name = strdup(name);
			d->addr = obj;
			
			p->sat_obj = d;
			p->next = root->object;
			root->object = p;
		}
		
		item=sat_dirfindnext(item);
	}
	
}

/*!
	\fn 	sat_dir_open()
	\brief	Open (create) the internal directory structures.
			Not to be called directly!
*/

void
sat_dir_open()
{
	
	if (__sat_root)
		return;
	
	// create root node
	SAT_DIR_NODE *root = (SAT_DIR_NODE *) calloc(1,sizeof(SAT_DIR_NODE));
	sys_chkptr(root);
	root->name = "";
	
	_sat_dir_scan(root,sat_objhome());
	__sat_root = root;
}


