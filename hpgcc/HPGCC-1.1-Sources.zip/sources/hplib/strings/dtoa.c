//& ****************************************************************************
//&
//& Written by Ingo Blank
//&
//& 2004/08		Initial implementation
//& 2005/07		Improved precision (long long arithmetics) 
//&
//& Copyright (C) 2004,2005 Ingo Blank
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

// $Header: /cvsroot/hpgcc/sources/hplib/strings/dtoa.c,v 1.21 2005/07/10 01:13:14 iblank Exp $

#include <hpstdlib.h>
#include <hpstring.h>
#include <hpstdio.h>
#include <hpmath.h>


#define MAXDIGITS 15
#define TINY_EXP 1.0e-15
#define BIG_EXP 1.0e15

#define DEFAULT_EXPO_SYM 'E'
#define NORMALIZED_MANTISSA 0
			
char *
__dtoa(double x, char *buf, char expo_sym)
{
	int digits,max_digits;
	int minus,expo,write_expo;
	char fraction[MAXDIGITS+1];
	char integral[MAXDIGITS+1];
	char exps[8];
	
	digits = minus = expo = write_expo = 0;
	max_digits = min(get_decimal_digits(),MAXDIGITS);
	memset(fraction,'0',max_digits);
	fraction[max_digits] = '\0';
	strcpy(integral,"0");
	
	
	if (x != 0.0) {
		
		int expo2;
		
		if ((minus = x < 0.0))
			x = -x;
		
		frexp(x,&expo2);
		expo = (int) (expo2*M_LN2/M_LN10);
		
		write_expo = ( expo_sym == 'e' || expo_sym == 'E' || (expo_sym == 'g' && ( x >= BIG_EXP || x <= TINY_EXP  || ((abs(expo)) > max_digits))) );
		
		if (write_expo) 
			// scale for exponential representation 
			x *= ipow(10.0,-expo);
		

		double ip;
		
		modf(x,&ip); 
		LONGLONG lip = (LONGLONG) ip;
		lltoa(lip,integral,10);
		
		LONGLONG nlp=1,lpow;
	
		int k;
		for(k = 0; k < max_digits-1; k++)
			nlp *= 10;
		lpow = 10 * nlp;
		
		LONGLONG lfrac;
		
		lfrac = (LONGLONG) dround(x * lpow,0) - lip * lpow;
		
		if (lfrac != 0LL) {
			
#if NORMALIZED_MANTISSA

			// Force a normalized exponential representation;
			// x.ddd Eeee , where x > 0
			
			// This is expensive in terms of space.
			// It adds an 2+ K overhead for the LONGLONG division
			
			if (write_expo && lip == 0LL) {
				LONGLONG nip;
				
				nip = lfrac / nlp;
				lfrac = 10*(lfrac - nip*nlp);
				lltoa(nip,integral,10);
				expo--;
				
			}
#endif
			char fmt[8];
			
			sprintf(fmt,"%%0%dL",max_digits);
			sprintf(fraction,fmt,lfrac);
		}
		
	}
	
	sprintf(buf,"%s%s%s%s",minus ? "-" : "",integral,max_digits ? get_decimal_separator() : "",fraction);
	
	if (write_expo) {
		int m;
		if ((m = expo < 0))
			expo = -expo;
		if (! (expo_sym == 'e' || expo_sym == 'E'))
			expo_sym = DEFAULT_EXPO_SYM;
		sprintf(exps,"%c%c%03d",expo_sym,m ? '-' : '+', expo);
		strcat(buf,exps);
	}
	
	return buf; 
	
}
