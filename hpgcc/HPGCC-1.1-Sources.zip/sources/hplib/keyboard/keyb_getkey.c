//& ****************************************************************************
//&
//& Written by Al Borowski, September 2004
//& 
//& Copyright (C) 2004 The HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************

#include <hpgcc49.h>

int keyb_getkey(int wait)
{
	
	//HP says the keyboard is debounced in hardware - yeah, right.	

	unsigned int volatile * GPGDAT = (int*) 0x7A00064; //data
	unsigned int volatile * GPGCON = (int*) 0x7A00060; //control
	int keyPress = 0;
	int col,row;
	int oldGPGCON = *GPGCON;
	int i; 
	int found=0; //'keypress found' flag

	int keyCode = 0; //the code to return


	int oldRTC=sys_setRTCTickPeriod(1); //speed up the RTC

	unsigned int rowData;
	
	if(wait==0){ //bail out, if not waiting and no keys pressed
		if(!keyb_isAnyKeyPressed()) return -1;
	}
	
	//if we're waiting, wait until any previous	keystroke is gone before recording a fresh key
	//this prevents any false reading from an earlier keypress.
	
	while ( ((*GPGDAT & 0xFE)!=0xFE) && wait ) ;  
	

	while((!found)){ //wait until a key is read sucessfully 

		rowData=0xFE;
		while ( (rowData==0xFE) && wait )  rowData=(*GPGDAT & 0xFE);//wait for a keypress

	//rowData contains information on the row
	
	// Scan keyboard to find the position


	
		for (col=0;col<8;col++){ //scan the columns
			unsigned int control = 1<<((col+8)*2); //set the correct col pin to output, others inputs
			control = control | 0xAAA9; //fix up the lower bits
			*GPGCON = control; // write the new control value.

			//wait a little while to take effect.
			for(i=0;i<500;i++);

			if(0xFE!=(*GPGDAT & 0xFE)){
				found=1;//found a match!
				break;
			}

		}


		*GPGCON = oldGPGCON; //restore register default (all columns selected)
	
		if(wait==0){ //if we're not waiting for a key, bail out rather then retry
		
			sys_setRTCTickPeriod(oldRTC); //restore old RTC value
			return -1;
		
		}
	
	}
	
	
	//now check the modifier keys (alpha, shifts etc)
	
	if(keyb_isON()) keyCode+=1<<8;
	if(keyb_isRS()) keyCode+=1<<9;
	if(keyb_isLS()) keyCode+=1<<10;
	if(keyb_isAlpha()) keyCode+=1<<11;	
	
	if(wait!=0){ //if we're waiting for a release, do the debouncing stuff
	
		sys_waitRTCTicks(4); //wait a bit to ensure the main key isn't bouncing
		//Wait for release
		while (((*GPGDAT & 0xFE)!=0xFE) && wait);
		sys_waitRTCTicks(2); //wait a bit so it stops bouncing

	}

		sys_setRTCTickPeriod(oldRTC); //restore old value

	//now decode the row from rowData
	
	for (row=0;row<10;row++){
			keyPress = !( (  (rowData)  >> (row+1)  )  &1);
			if (keyPress) break;
	}

	keyCode+=(row<<4)+col;

	return keyCode;
}

