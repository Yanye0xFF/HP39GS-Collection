//& ****************************************************************************
//&
//& Copyright (C) 2004,2005 The HP-GCC Development Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************


// $Header: /cvsroot/hpgcc/sources/hplib/sys/qsort.c,v 1.2 2005/05/08 15:21:09 iblank Exp $

#include <hpstdlib.h>

static	void qsort1(char *, char *, size_t);
static	int (*qcompar)(const char *, const char *);
static	void qexchg(char *, char *, size_t);
static	void q3exchg(char *, char *, char *, size_t);

void
qsort(void *base, size_t n_elements, size_t width,
      int (*compar)(const void *, const void *))
{
	
	if (!n_elements) return;
	qcompar = (int (*)(const char *, const char *)) compar;
	qsort1(base, (char *)base + (n_elements - 1) * width, width);
}

static void
qsort1(char *a1, char *a2, register size_t width)
{
	register char *left, *right;
	register char *lefteq, *righteq;
	int cmp;

	for (;;) {
		if (a2 <= a1) return;
		left = a1;
		right = a2;
		lefteq = righteq = a1 + width * (((a2-a1)+width)/(2*width));
		
repeat:
		while (left < lefteq && (cmp = (*qcompar)(left, lefteq)) <= 0) 
			if (cmp < 0) 
				left += width;
			else {
				
				lefteq -= width;
				qexchg(left, lefteq, width);
			}
		
		while (right > righteq) {
			if ((cmp = (*qcompar)(right, righteq)) < 0) {
				
				if (left < lefteq) {
					qexchg(left, right, width);
					left += width;
					right -= width;
					goto repeat;
				}
			
				righteq += width;
				q3exchg(left, righteq, right, width);
				lefteq += width;
				left = lefteq;
			}
			else if (cmp == 0) {
				righteq += width;
				qexchg(right, righteq, width);
			}
			else	right -= width;
		}
		if (left < lefteq) {
			
			lefteq -= width;
			q3exchg(right, lefteq, left, width);
			righteq -= width;
			right = righteq;
			goto repeat;
		}
	
		qsort1(a1, lefteq - width, width);
		a1 = righteq + width;
	}
	
}

static void
qexchg(register char *p, register char *q,
	  register size_t n)
{
	register int c;

	while (n-- > 0) {
		c = *p;
		*p++ = *q;
		*q++ = c;
	}
}

static void
q3exchg(register char *p, register char *q, register char *r,
	   register size_t n)
{
	register int c;

	while (n-- > 0) {
		c = *p;
		*p++ = *r;
		*r++ = *q;
		*q++ = c;
	}
}
