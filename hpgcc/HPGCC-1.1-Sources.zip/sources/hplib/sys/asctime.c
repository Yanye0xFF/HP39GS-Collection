//& ****************************************************************************
//&
//& Written by Ingo Blank, August 2004
//& 
//& Copyright (C) 2004,2005 Ingo Blank,  HP-GCC Team
//&
//& ****************************************************************************
//&
//&
//& This file is part of HP-GCC.
//&
//& HP-GCC is free software; you can redistribute it and/or modify
//& it under the terms of the GNU General Public License as published by
//& the Free Software Foundation; either version 2, or (at your option)
//& any later version.
//& 
//& HP-GCC is distributed in the hope that it will be useful,
//& but WITHOUT ANY WARRANTY; without even the implied warranty of
//& MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//& GNU General Public License for more details.
//& 
//& You should have received a copy of the GNU General Public License
//& along with HP-GCC; see the file COPYING. 
//&
//& As a special exception, you may use this file as part of a free software
//& library without restriction.  Specifically, if other files instantiate
//& templates or use macros or inline functions from this file, or you compile
//& this file and link it with other files to produce an executable, this
//& file does not by itself cause the resulting executable to be covered by
//& the GNU General Public License.  This exception does not however
//& invalidate any other reasons why the executable file might be covered by
//& the GNU General Public License.
//&
//& ****************************************************************************



// $Header: /cvsroot/hpgcc/sources/hplib/sys/asctime.c,v 1.2 2005/06/24 20:32:45 iblank Exp $

#include <hpgcc49.h>

char *
_isotime(const struct tm *tt,int strict)
{
	static char s[32];
	struct tm tmb,*t;
	
	if (tt == NULL) {
		sys_tm_RTC(&tmb);
		t = &tmb;
	}
	else
		t = (struct tm *)tt;
	
	isprintf(s,"%4d-%02d-%02d%c%02d:%02d:%02d",
				t->tm_year + 1900,
				t->tm_mon + 1,
				t->tm_mday,
				strict ? 'T' : ' ',
				t->tm_hour,
				t->tm_min,
				t->tm_sec);
	
	return s;
}


char *
asctime(const struct tm *tt)
{
	return _isotime(tt,0);
}
