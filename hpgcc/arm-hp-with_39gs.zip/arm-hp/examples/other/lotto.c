/*
    lotto.c
    
    Draw N out of K ( 6 ; 49 ) numbers
    Simple program demonstrating the use of bitvectors as sets.
    
    ibl
    2005-08-21
*/

#ifdef PC
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#define LONGLONG long long
#define ULONGLONG unsigned long long
#define WAIT_CANCEL
#else
#define TINY_PRINTF 1
#include <hpgcc49.h>
#endif


int
bit_count(ULONGLONG b)
{
    if (b == 0)
        return 0;
    return bit_count(b >> 1) + (b & 1);
}

void
draw_and_print()
{
    #define N 6
    #define K 49
    
    ULONGLONG bits = 0LL;
    int z;
    
    // Draw N out of K  numbers ...
   
    while (bit_count(bits) != N) 
        bits |= (1ULL << (rand() % K));
    
    // ... and display them
   
    for (z=1; bits;) 
        
        if (bits & 1) {
            printf("%2d ",z);
            bits >>= 1;
            z++; 
           
        }
        else 
            do {
                bits >>= 1;
                z++;
            } while(!(bits & 1));
            
            
    printf("\n");
}
    

int
main()
{
   
    
    char **argv;
    int  argc,d;
    
#ifdef PC
    srand(time(0));
#else
    clear_screen();
	srand(sys_RTC_seconds());
#endif
    printf("Here are your Lotto numbers:\n\n");
    
    if ((argc = sat_stack_pop_stdargs(&argv))) 
        d = atoi(argv[0]);
    else
        d = 1;
    
    for(;d--;)
        draw_and_print();
    
    printf("\nGood luck!\n");
    

    WAIT_CANCEL;
    
	return 0;
}

