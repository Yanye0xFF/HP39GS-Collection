// Eratosthenes sieve with a priori pix(N) estimation, depending on free memory...
// Ingo Blank, Dec. 2004

#include <hpgcc49.h>


#define bitset(a,i) (a[i >> 5] & (1 << ( i & 31)))
#define bitclear(a,i) a[i >> 5] &= ~(1 << (i & 31))

typedef struct _node {
	int val;
	struct _node *nxt;
} node, *pnode;


pnode
append(pnode list, int value)
{
	pnode q;
	
	q = (pnode) malloc(sizeof(node));
	q->val = value;
	q->nxt = list;
	return q;
}

pnode
reverse(pnode list)
{
	pnode p,new_list = NULL;
	while(list) {
		new_list = append(new_list,list->val);
		p = list;
		list = list->nxt;
		free(p);
	}
	return new_list;
}

int
list_len(pnode list)
{
	pnode q;
	int n;
	
	for (n = 0, q = list; q ; n++ , q = q->nxt);
	return n;
}

int
erato(int prime_list[],int n, int iter , int dump)
{
	int N,i,k,it,primes=0;
	unsigned bits[N=(n >> 5)+1];
	
	for (it = 0; it < iter ; it ++) {
	
		for(i = 0; i < N; i++)
			bits[i] = 0xFFFFFFFF;
		
		primes = 0;
		
		for(i = 2; i < n; i++)
			if (bitset(bits,i)) {
				if ( it == 0)
					prime_list[primes]=i;
				primes++;
				if(dump) 
					printf("%d\t",i);
				for (k = i ; k < n; k += i)
					bitclear(bits,k);
			}
	}
		
	return primes;
}


double
f_mem(double x)
{
	// pix(x) * sizeof(int) + sieve_size
	
	return 1.05 * sizeof(int) * (x / (log(x) - 1.0)) + x / 8.0;
	
}


int 
main()
{
	
	int N,p,iter,t1;
	int pix,*p_list;
	extern int _ram_size; 
	char *header,*decor;
	
	clear_screen();
	sys_slowOff();
	//set_speed(CPU_SPEED_FASTEST);
	
	header = "***  Eratosthenes sieve  ***";
	decor  = strdup(header);
	strset(decor,'*');
	printf("%s\n%s\n%s\n",decor,header,decor);
	
	N = (int)newton(f_mem,1000.0,(double)_ram_size) ;
	iter = 1;
	
	// estimate pix(N)
	pix = (int) (1.05 * ((double)N / (log((double)N)-1.0)));
	printf("Estimated memory usage: %d KB\n",(pix*sizeof(int)+N/8)/1024);
	p_list = (int *) calloc(pix,sizeof(int));
	
	t1 = sys_RTC_seconds();
	
	p = erato(p_list,N,iter,0);
	printf("\npix(%d) => %d primes.\n",N,p);
	printf("%d Iterations.\n\n",iter);
	printf("%d primes computed in %d sec.\n\n", p*iter, sys_RTC_seconds()-t1);
	
	
	/*
	i = 0;
	while (q) {
		if (p == -1)
			putchar(16);
		printf("%d%s",q->val, ++i % 4  ?  " " : "\n");
		p--;
		r = q;
		q = q->nxt;
		free(r);
	}
	
	*/
	
	 beep();
	sys_slowOn();
	WAIT_CANCEL ;
	
	return 0;
	
}
