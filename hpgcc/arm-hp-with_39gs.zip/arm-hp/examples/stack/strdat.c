/*
 *  Write a string in stack level #2 to a file named as string in stack level #1
 *  on the SD card.
 *  The string is stored as a regular text file, without the HPHP49 object header.
 *
 * Ingo Blank
 * 2005-08-11
 */

  
#include <hpgcc49.h>

int
main()
{
    
    unsigned stack = sat_stack_init();
    
    char *filename,*string_data;
    FILE *f;
    
    if( (filename = sat_stack_pop_string_alloc())  &&
        (string_data = sat_stack_pop_string_alloc()) && 
        (f = fopen(filename,"w")) ) {
            
        fputs(string_data,f);
        fclose(f);
            
    } else beep(); // error!
    
    sat_stack_exit(stack);
    
    return 0;
}

