** fixed length variables of function aplet 1.1

INCLUDE =Sharedvar.h

ASSEMBLE
	Vfield L34,Root
RPL
	% 0

ASSEMBLE
	Vfield Root,Area
RPL
	% 0

ASSEMBLE
	Vfield Area,Slope
RPL
	% 0

ASSEMBLE
	Vfield Slope,Isect
RPL
	% 0

ASSEMBLE
	Vfield Isect,Extremum
RPL
	% 0

