#include <hpgcc49.h> //the standard HP lib
#include <hpstdio.h>
#include <hpconio.h>
#include <hpsys.h>
#include <kos.h>
 
int main(void)
{ 
   
	kos_ClearLcd(); 
	
	while(!keyb_isON()); //loop until ON pressed
	
	return 0;

}

