#include "stack.h"

void
push(NODE **head, void *data)
{
	NODE *n = sys_chkptr(malloc(sizeof(NODE)));
	n->prev = *head;
	n->data = data;
	*head = n;
}


void *
pop(NODE **head)
{
	if (!*head) {
		return NULL;
	}
	NODE *n = *head;
	void *data = (*head)->data;
	*head = (*head)->prev;
	free(n);
	return data;
}
