#include <saturn.h>
#include <syscall.h>
#include <hpconio.h>
#include <hpstring.h>
#include "hp39kbd.h"
#include "stack.h"
#include "display.h"
#include "main.h"

int event_handler(unsigned row, unsigned col) {
	// [APLET], [HOME]
	if ((row == 0 && col == 7) || (row == 0 && col == 4) || (row == 6 && col == 6)) {
		// exit immediately
		return 27;
	} else {
		// 100ms per tick
		set_indicator(INDICATOR_WAIT, TRUE);
        delay(100000);
		set_indicator(INDICATOR_WAIT, FALSE);
	}

	if (col == 6) {
        // [UP]: 0, [LEFT]: 1, [DOWN]: 2, [RIGHT]: 3
		return row + 20;
	} else if (row == 1 && col == 7) {
        // [VIEWS]
		return 28;				
	} else if (3 <= row && row <= 5 && 1 <= col && col <= 3) {
		return (6 - row) * 3 - col + 1;
	}
	// unhandled keys
	return 0;
}

inline int sat_strlen(unsigned sat_addr) {
	return ((int) sat_peek_sat_addr(sat_addr + 5) - 5) / 2;
}

inline char *sat_strdup(unsigned sat_addr) {
	unsigned len = sat_strlen(sat_addr);
	char *buf = sys_chkptr(malloc(len));
	return sat_peek_sat_bytes(buf, sat_addr + 10, len);
}

void display_title(const char *str) {
	unsigned len = strlen(str) + 2;
	extern int __scr_w;
	int right = (__scr_w - len) >> 1, left = __scr_w - len - right;

	clear_screen();

	while (left--) {
		putchar('\x7f');
	}
	putchar(' ');
	while (*str) {
		putchar(*str++);
	}
	putchar(' ');
	while (right--) {
		putchar('\x7f'); 
	}
	for (int i = 0; i < 6; i++) {
		set_indicator(i, FALSE);
	}
}

void display_item(unsigned count, SAT_OBJ_DSCR * obj) {
	putchar(' ');
	putchar(' ');
	putchar('0' + count);
	putchar(' ');

	char *name = obj->name + 1;
	while (*name) {
		putchar(*name++);
	}

	char buf[7];
	utoa(sat_strlen(obj->addr), buf, 10);
	for (unsigned i = obj->name - name - strlen(buf) + 28; i > 0; i--) {
		putchar(' ');
	}
	puts(buf);
}

int note_explorer(SAT_DIR_ENTRY * init) {
	display_title("Gallery");
	putchar('\n');

	if (!init) {
		SAT_DIR_NODE *dir = _sat_find_path("/'notesdir");
		init = dir->object;
	} else {
		set_indicator(INDICATOR_LSHIFT, TRUE);
	}

	unsigned count = 0;
	SAT_DIR_ENTRY *next_page = NULL;
	for (SAT_DIR_ENTRY * entry = init; entry; entry = entry->next) {
		SAT_OBJ_DSCR *obj = entry->sat_obj;
		if (obj->name[0] == ';') {
			continue;
		}
		if (count == 8) {
			next_page = entry;
			set_indicator(INDICATOR_RSHIFT, TRUE);
			break;
		}
		count++;
		display_item(count, obj);
	}
	gotoxy(0, 9);

	static NODE *head;
	for (;;) {
		int key = get_key();
		if (key == 27) {
            // exit program
			return 0;			
		} else if ((key == 22 || key == 23) && next_page) {
            // page down
			push(&head, next_page);
			return note_explorer(next_page);	
		} else if (key == 20 || key == 21) {
            // page up
			pop(&head);
			return note_explorer(pop(&head));	
		} else if (1 <= key && key <= count) {
			for (SAT_DIR_ENTRY * entry = init; entry; entry = entry->next) {
				SAT_OBJ_DSCR *obj = entry->sat_obj;
				if (obj->name[0] == ';') {
					continue;
				}
				key--;
				if (!key) {
					return note_viewer(obj, head ? head->data : NULL);
				}
			}
		}
	}
}

inline void showIndicator(){
    set_indicator(INDICATOR_LSHIFT, TRUE);
    set_indicator(INDICATOR_RSHIFT, TRUE);
}

void display_image(char *buffer , int height, int width,int loffset,int hoffset) {
    int scr_index = 0;
    int drawY = 0,drawX = 0;
    unsigned char *ptr;

    SysCall(ClearLcdEntry);

    drawY = (height > 64) ? 64 : height;
    drawX = ((width >> 3) > 16) ? 16 : (width >> 3);

    for(int y = 0; y < drawY; y++)  {
        scr_index = (y << 4) + (y << 2);
        ptr = buffer + ((y + hoffset) * (width >> 3) + FILE_HEAD_MARGIN + loffset) ;
        for(int x = 0; x < drawX; x++) {
            __display_buf[scr_index++] = *ptr;
            ptr++;
        }
    }
}

int note_viewer(SAT_OBJ_DSCR * obj, SAT_DIR_ENTRY * ref) {
    int img_width = 0, img_height = 0;
    int key;
    //current position
    volatile int top = 0,left = 0,buttom = 0,right = 0;
    const char *error = "\n\n\n\n      File is not a picture";
	char *buffer = sat_strdup(obj->addr);

    //check file header (1 byte)
    if(buffer[0] != 0xFD) {
        display_title("Gallery");
        puts(error);
        delay(1000000);
        free((void *) buffer);      
        return note_explorer(ref);
    }
    //read file width (2bytes)
    img_width = (buffer[1] & 0x000000FF) << 8;
    img_width |= buffer[2];
    //read file height (2bytes)
    img_height = (buffer[3] & 0x000000FF) << 8;
    img_height |= buffer[4];
    //init position (top_left)
    display_image(buffer, img_height, img_width, 0, 0);
    //calc margin
    buttom = (img_height > 64) ? img_height - 64 : 0;
    right = (img_width > 128) ? (img_width - 128) >> 3 : 0;

    while(1) {
        key = get_key();
        if(key == 27) {
            // exit program
            return 0;
        }else if(key == 28) {
            // go back to the list
            free((void *) buffer);
            return note_explorer(ref);
        }else if(key == 20) {
            //up
            if(top) {
                buttom += 4;
                top -= 4;
                display_image(buffer, img_height ,img_width, left,top);
            }
        }else if(key == 21) {
            //left
            if(left) {
                right++;
                left--;
                display_image(buffer, img_height ,img_width, left,top);
                showIndicator();
			}else {
                set_indicator(INDICATOR_LSHIFT, FALSE);
			}
        }else if(key == 22) {
            //down
            if(buttom) {
                buttom -= 4;
                top += 4;
                display_image(buffer, img_height,img_width, left,top);
            }
        }else if(key == 23) {
            //right pressed
			if(right) {
                right--;
                left++;
                display_image(buffer, img_height,img_width, left,top);
                showIndicator();
            }else {
                set_indicator(INDICATOR_RSHIFT, FALSE);
            }
        }
    }
}
