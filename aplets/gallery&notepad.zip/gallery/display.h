#ifndef _DISPLAY_H
#define _DISPLAY_H

#define SCREEN_WIDTH    131
#define SCREEN_HEIGHT   64
#define BYTES_PER_ROW   20

#define FILE_HEAD_MARGIN 5

#include <stdint.h>
extern uint8_t *__display_buf;

#define indicator(n) __display_buf[BYTES_PER_ROW * (n) + (SCREEN_WIDTH >> 3)]
#define INDICATOR_MASK (1 << (SCREEN_WIDTH & 7))
#define get_indicator(n) (indicator(n) | INDICATOR_MASK)
#define set_indicator(n, value) { \
	if (value) indicator(n) |= INDICATOR_MASK; \
	else indicator(n) &= ~INDICATOR_MASK; \
};

#define INDICATOR_REMOTE    0
#define INDICATOR_LSHIFT    1
#define INDICATOR_RSHIFT    2
#define INDICATOR_ALPHA     3
#define INDICATOR_BATTERY   4
#define INDICATOR_WAIT      5

#endif
