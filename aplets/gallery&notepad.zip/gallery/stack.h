#ifndef _STACK_H
#define _STACK_H

#include <hpstdlib.h>

typedef struct node {
    struct node *prev;
    void *data;
} NODE;

void push(NODE **head, void *data);
void *pop(NODE **head);

#endif
