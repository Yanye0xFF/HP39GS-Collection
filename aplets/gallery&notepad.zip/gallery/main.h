#ifndef _MAIN_H
#define _MAIN_H

#include <stdint.h>
#include <satdir.h>

int event_handler(unsigned row, unsigned col);
int note_explorer(SAT_DIR_ENTRY *init);
int note_viewer(SAT_OBJ_DSCR *obj, SAT_DIR_ENTRY *ref);

#endif
