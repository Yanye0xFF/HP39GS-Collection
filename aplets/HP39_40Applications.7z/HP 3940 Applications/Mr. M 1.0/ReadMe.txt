Mr.M
By Pavel Poutchkarev
Version 1.0
2001
Graphin84@yahoo.com

This program shows the time and the date set up on
your calculator (you need to set up the both of them).
It can show time ones, or infinite times, so it will
work as a watch.

To switch the program off press [ON] key a few times
really quick, because of this the program migth be used
as some sort of protection from people that do not know
how to use HP calculators, and so they won't screw up
something.

0.9Kb