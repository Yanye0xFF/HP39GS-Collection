		*****************************************
		*	      Grob Filer Tools		*
		*		Source Code		*
		*              for HP39/40G		*
		*              by Rob Morgan	        *
		*       e-mail: robsta@tpg.com.au	*
		*****************************************

Send bug reports, comments or ideas to: robsta@tpg.com.au

*******************
* Instructions	  *
*******************
1. Download ADK39 and install it.
2. Run pre.bat to convert text files -> prg files.
2. Open the *.PRG files in the ADK for editing.

*******************
* Pre-edit.bat   *
*******************
Is a simple windows batch script that prepares the source files for 
editing with the ADK.

*******************
* Source Files    *
*******************
Filer.txt 	- The core program for grob filer.		Src Ver: 1.1
Gel.txt 	- The Grob Encryption Library.			Src Ver: 1.0


*******************
* Known Bugs	  *
*******************
+The ADK was designed for older operating systems, therefore 8 character
filenames are recommended.

*******************
* HISTORY:	  *
*******************

Version 1.1:
------------
+Stable Release
+Source Included
+First Public Release