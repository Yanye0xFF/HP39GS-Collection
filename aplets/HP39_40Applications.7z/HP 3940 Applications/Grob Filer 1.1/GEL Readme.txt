		*****************************************
		*	         GEL v1.0		*
		*              for HP39/40G		*
		*              by Rob Morgan	        *
		*       e-mail: robsta@tpg.com.au	*
		*****************************************

Send bug reports, comments or ideas to: robsta@tpg.com.au

*******************
* Overview	  *
*******************
GEL is a program written in USER RPL that encyrpts Grobs (Graphic Objects) based
on a specified pin code. It uses the specified pin code to generate random point
inversions, rendering the image unviewable by the human eye. If a grob is
encrypted using one pin and decrypted with another pin it will be corrupted and 
the screen contents will be garbled. The PIN number maybe comprised of any number
of digits but 4 digit codes work best.

Size Compilied in Program Catalogue: 2.4kb

*******************
* Usage		  *
*******************
GEL is a USER RPL library that is called from Grob Filer. It is required to be 
installed in the program catalogue for grob encryption purposes.

*******************
* Algorithm   	  *
*******************
The algorithm GEL uses to encrypt grobs is based on mathematical formulae. Different
PIN codes with have varying effects. It also maybe possible for a different PIN code
to decrypt a grob encrypted with another PIN code.

*******************
* HISTORY:	  *
*******************

Version 1.0:
------------
+First public release