		*****************************************
		*	      Grob Filer v1.1		*
		*              for HP39/40G		*
		*              by Rob Morgan	        *
		*       e-mail: robsta@tpg.com.au	*
		*****************************************

Send bug reports, comments or ideas to: robsta@tpg.com.au

*******************
* Overview	  *
*******************
Grob filer is an excellent grob manager. It has
the ability to copy, erase, view and encrypt
grobs. It's downside is that is written in User
RPL and is slow and takes a long time to compile.

Size Compilied in Program Catalogue: 31kb

*******************
* IMPORTANT	  *
*******************

The first time this User RPL program is run
the calculator must convert it to machine code.
This program is very large and takes about 4
minutes. While this process is occurring no visual
status will be displayed. It may seem your calculator
is frozen but resist from resetting it.

*******************
* Usage		  *
*******************
When you start Grob Filer you are presented with
a title screen. Press any key. 
Enter 0-9 to select a grob...

An overview screen appears for the selected grob
showing some information, press 1 for a list of
options or 2 to return to the menu.

*******************
* Known Bugs:	  *
*******************
+You may not edit the program code in the program catalogue. The calulator
cannot edit files of this size.

*******************
* HISTORY:	  *
*******************

Version 1.1:
------------
+Stable Release
+Source Included
+First Public Release
+Code edited to run faster

Version 1.0:
------------
+Beta Version
+Slow Compile
+Large Footprint

Version 0.5:
------------
+Development Release
+Buggy Code