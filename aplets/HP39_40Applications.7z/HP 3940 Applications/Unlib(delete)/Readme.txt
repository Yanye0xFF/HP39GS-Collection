		*****************************************
		*	           UnLib		*
		*              for HP39/40G		*
		*  	         by Noda	        *
		*       http://www.noda.online.fr	*
		*****************************************

A simple library that allows you to delete other libraries.

Use: UNLIB(X) where X is the library number in decimal (see it in the memory viewer).

NOTE: It can't delete itself, but it's only 189 bytes, so...

Use the HPTools to compile the source.