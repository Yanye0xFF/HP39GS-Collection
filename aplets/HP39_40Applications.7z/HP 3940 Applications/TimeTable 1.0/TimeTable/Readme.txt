TimeTable
Version 1
�2002-2003 Green Monkey Creations and Geek_Boi
Http://www.Green-Monkey.hq3.com/

A.About
TimeTable is a program which is to be used with the HP39/40G. It reads numbers from a matrix which corresponds to subjects and then displays them on the screen. To install this program you will need HPGcomm and have a cable ready. If you need more help on the subject visit My site or HP Home view.
 
B.Extra setup needed
Before TimeTable will function properly there are some steps that need to be done to tell the calculator the dimensions of your time table and what subjects you have.
1. Edit ".TTvars" and enter the number of periods and number of days in the specified spots.
2. Next edit ".TTsubs" and following the exaplmle enter all your subjects and assign them each a number. I suggest you make a note of what subjects have what numbers.
3. Then edit Matrix number 0 and enter your time table using the numbers allocated in the previous step with days at the top and periods down the side.

Most of this information is also in the note view on the aplet. 
