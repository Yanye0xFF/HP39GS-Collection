#ifndef __KEY_EVENT_H__
#define __KEY_EVENT_H__

#define KEY_EVENT_NULL -100
#define KEY_EVENT_HOME 200

#endif
