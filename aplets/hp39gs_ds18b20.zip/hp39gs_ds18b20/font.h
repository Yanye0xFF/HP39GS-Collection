#ifndef __FONT_H__
#define __FONT_H__

#define FONT_WIDTH 16
#define FONT_HEIGHT 20

#define ICON_WIDTH 16
#define ICON_HEIGHT 10

extern const unsigned char fonts[][40];
extern unsigned char icons[][20];

#endif
