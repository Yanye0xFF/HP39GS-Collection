#ifndef _ROMVIEWER_H
#define _ROMVIEWER_H

#include <hpgcc49.h>
#include "hp39kbd.h"
#include <hpgraphics.h>

int event_handler(unsigned col, unsigned row);

int main(void);

#endif
