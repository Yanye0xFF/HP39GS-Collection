#ifndef _MASD_H_
#define _MASD_H_

extern void doassemblem(char *);
extern void docodem(char *);
extern void Masd_ExtractField(char *);
extern int MASD_LongCteError;


#endif
