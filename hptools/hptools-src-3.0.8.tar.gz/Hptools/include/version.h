#define VERSTRING "HP Development Tools V3.0.8 (12/06/2002)"
