#ifndef _DEFER_H_
#define _DEFER_H_

#include "rplcomp.h"

extern void	drop_ary(int, struct LINE *);
extern struct ARRY	*push_ary(void);
extern void	add_obj(struct ARRY *);

#endif
