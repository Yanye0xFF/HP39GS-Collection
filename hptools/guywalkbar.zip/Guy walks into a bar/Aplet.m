TITLE    Guy walks into a bar
OUTPUT   GWIAB.000
LLIST    aplet.lr
SUPPRESS XR
OPTION   CODE
REL      aplet.o
END
